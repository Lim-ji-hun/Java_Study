package ch09_quiz;

public class Circle implements Shape {
	
	private double radius;
	private final double PI = 3.141592;

	public Circle(double radius) {
		this.radius = radius;
	}
	
	public double area() {  // 도형 넓이 계산
		return radius*radius*PI;
	}
	
	public void drawing() { // 도형 그리기
		System.out.println("원 그리기 - 넓이 : " + area());
	}
	
}