package ch09_quiz;

import java.util.Scanner;

public class ShapeTest {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("1.사각형   2.원  선택 >> ");
		int select = scanner.nextInt();
		
		System.out.println();
		
		Shape shape = null;
		switch(select) {
		case 1: // 사각형
			System.out.println("--- 사각형 ---");
			System.out.print("가로 길이 입력 > ");
			double width = scanner.nextDouble();
			System.out.print("세로 길이 입력 > ");
			double height = scanner.nextDouble();
			
			shape = new Rectangle(width, height);
			break;
		case 2: // 원
			System.out.println("---   원   ---");
			System.out.print("반지름 입력 > ");
			double radius = scanner.nextDouble();
			
			shape = new Circle(radius);
			break;
		default:
			System.out.println("도형 선택 오류~");
		}
		
		if(shape != null) {
			shape.drawing();
		}
		
	}
	
}




