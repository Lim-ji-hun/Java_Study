package ch09_quiz;

/*
 * Shape interface 를 상속받은 Rectangle(사각형), Circle(원) class 를 정의하고,
 * ShapeTest class 에서 Shape 변수를 사용해서 다형성을 구현한 코드를 작성하세요
 */


public interface Shape {
	
	
	public double area();
	
	public void drawing();

}
