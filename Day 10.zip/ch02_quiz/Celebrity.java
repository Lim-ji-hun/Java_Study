package ch02_quiz;
/*
 * Celebrity class 를 정의하고, PersonTest class 에서 테스트 하세요
 * - Person class 를 상속받고, 소속사의 관리가 가능합니다
 */
public class Celebrity extends Person{
	
	private String company;
	
	public Celebrity(String name, int old, String company) {
		super(name, old);
		this.company = company;
		
	}
	public void CelebrityInfo() {
		super.PersonInfo();
		System.out.println("소속사 : " + company);

	}
	
}
