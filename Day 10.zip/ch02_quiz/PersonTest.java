package ch02_quiz;

public class PersonTest {
	public static void main(String[] args) {
		Celebrity try1 = new Celebrity("가나다", 20, "카카오");
		try1.CelebrityInfo();
		
		System.out.println();
		
		Police try2 = new Police("가나다", 20, "소장");
		try2.PoliceInfo();
	}

}
