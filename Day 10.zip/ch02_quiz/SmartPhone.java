package ch02_quiz;

/*
 * SmartPhone class 를 정의하고, PhoneTest class 에서 테스트 하세요
 * - Product class 상속받습니다
 * - 전화번호, 통신사의 관리가 가능합니다
 */

public class SmartPhone extends Product {
	
	private int number;
	private String com;
	
	public SmartPhone(String title, int prise, int number, String com) {
		super(title, prise);
		this.number = number;
		this.com = com;
	}
	

	
	public void phoneInfo() {
		System.out.println("--- 스마트폰 정보 ---");
		super.productInfo();
		System.out.println("전화번호 : " + number);
		System.out.println("통신사   : " + com);
	}
}
