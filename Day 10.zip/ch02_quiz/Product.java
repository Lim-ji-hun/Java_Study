package ch02_quiz;

/*
 * Product class 를 정의하세요
 * - 제품명, 가격의 관리가 가능합니다
 */


public class Product {
	
	private String title;
	private int prise;
	
	public Product(String title, int prise) {
		this.title = title;
		this.prise = prise;
	}
	
//	public String getTitle() {return title;}
//	
//	
//	public int getPrise() {return prise;}
	
	public void productInfo() {
		System.out.println("제품명 : " + title);
		System.out.println("가격   : " + prise + " 원");
	}

}
