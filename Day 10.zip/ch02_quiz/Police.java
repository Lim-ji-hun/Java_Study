package ch02_quiz;
/*
 * Police class 를 정의하고, PersonTest class 에서 테스트 하세요
 * - Person class 를 상속받고, 계급의 관리가 가능합니다
 */
public class Police extends Person {
	
	private String rank;
	
	public Police(String name, int old, String rank) {
		super(name, old);
		this.rank = rank;
	}
	
	public void PoliceInfo() {
		super.PersonInfo();
		System.out.println("계급 : " + rank);

	}

}
