package ch02_quiz;

public class PhoneTest {
	
	public static void main(String[] args) {
		SmartPhone phone = new SmartPhone("갤럭시 s24", 1400000, 01011112222, "SKT");
		phone.phoneInfo();
		
	}

}
