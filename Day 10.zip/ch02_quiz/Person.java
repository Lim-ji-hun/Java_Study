package ch02_quiz;

/*
 * Person class 를 정의하세요
 * - 이름, 나이의 관리가 가능합니다
 */

public class Person {
	
	private String name;
	private int old;
	
	public Person(String name, int old) {
		
		this.name = name;
		this.old = old;
		
	}
	
	public String getName() {return name;}
	public int getOld() {return old;}
	
	public void PersonInfo() {
		
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + old);
		
	}
	
	
	
	
	
	
}
