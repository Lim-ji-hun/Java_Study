package ch06_quiz;

public class AirForce extends Military{
	
	public AirForce(String name) {
		super(name);
	}
	
	public void attack() {
		System.out.println(getName() + " 공격");
	}
	
	public void move() {
		System.out.println(getName() + " 이동");
	}

}