package ch06_quiz;

public class Army extends Military{

	public Army(String name) {
		super(name);
	}
	
	public void attack() {
		System.out.println(getName() + " 공격");
	}
	
	public void move() {
		System.out.println(getName() + " 이동");
	}

}
