package ch06_quiz;

public class Navy extends Military{
	
	public Navy(String name) {
		super(name);
	}
	
	public void attack() {
		System.out.println(getName() + " 공격");
	}
	
	public void move() {
		System.out.println(getName() + " 이동");
	}

}