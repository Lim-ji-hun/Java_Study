package ch06_quiz;

public class MilitaryTest {
	public static void main(String[] args) {
		
		Army army = new Army("육군");
		army.attack();
		army.move();
		
		Army Navy = new Army("해군");
		Navy.attack();
		Navy.move();
		
		Army AirForce = new Army("공군");
		AirForce.attack();
		AirForce.move();
		
	}


}
