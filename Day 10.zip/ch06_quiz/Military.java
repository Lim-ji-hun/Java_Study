package ch06_quiz;

/*
 * Military class 를 상속받는 Army, Navy, AirForce class 를 정의하세요
 * - MilitaryTest class 에서 Military class 변수를 사용해서 다형성을 구현한 코드를 작성하세요
 */

public abstract class Military {

   private String name;  // 군대 이름(육군, 해군, 공군)
   
   public Military(String name) {
	   this.name = name;
   }
   
   public String getName() {return name;}
   
   public abstract void attack();  // 공격
   public abstract void move();    // 이동
   
}


