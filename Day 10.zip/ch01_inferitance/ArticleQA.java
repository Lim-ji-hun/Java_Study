package ch01_inferitance;

public class ArticleQA extends Article {
	
	private String answer;
	
	public String getAnswer() { return answer;}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	public void result() {
		System.out.println("질문/답변 [ 번호 : "+getNo() + " - 질문 : " + getTitle() + " - 답변 : " + answer);
	}
	
	
	

}
