package ch01_inferitance;

public class ArticleTest {
	public static void main(String[] args) {
		ArticleQA qa1 = new ArticleQA();
		qa1.setNo(1);
		qa1.getTitle("첫번째 질문?");
		qa1.setAnswer("답변입니다.");
		qa1.result();
		
		System.out.println();
		
		ArticleFile af = new ArticleFile(1, "상속 연습", "상속.pdf");
		af.fileInfo();
	
	}
	
	

}
