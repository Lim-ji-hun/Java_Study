package ch01_inferitance;

public class ArticleFile extends Article {
	
	private String fileName;
	
	public ArticleFile() {}
	
	public ArticleFile(int no, String title, String fileName) {
		super(no, title);
		this.fileName = fileName;
	}
	
	public String getFileName() {return fileName;}
	public void setFilename(String fileName) {
		this.fileName = fileName;
	}
	
	public void fileInfo() {
		System.out.println("지료실 [ No." + getNo() + " - 제목 : " + getTitle() + " - 파일명 : " + fileName + " ]" );
	}
	
	
	
	
	

}
