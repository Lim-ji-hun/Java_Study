package ch01_inferitance;

/*
 * 상속(inheritance)
 * 기존class의 내용을 그대로 가져와서 새로운 class를 정의 하는 것  
 * 자식클래스를 객체를 생성할때
 * 자식클래스의 생성자에서 super() 를 사용해서 부모클래스의 생성자를 먼저 생성하고
 * 자식클래스의 생성자가 진행됨
 * 상속을 하더라도 접근제한자는 그래로 유지됨(부모클래스의 private는 직접 연결이 불자능)
 * 
 * 상속 방번
 * class 자식클래스 extends 부모클래스 {
 * 
 * }
 * 
 */

public class PointTriple extends Point {
	
	private int pz;
	
	public PointTriple() {
		System.out.println("-PointTriple-");
	}
	
	public PointTriple(int px, int py, int pz) {
		super(px, py);
		System.out.println("-PointTriple(int px, int py, int pz)-");
		this.pz = pz;
	}
	
	public void threePoint() {
		System.out.println("좌표 x : " + getPx() + "좌표 y : " + getPy() + "좌표 z : " + pz);
	}
	
}
