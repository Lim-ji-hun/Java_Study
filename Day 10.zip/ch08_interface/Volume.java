package ch08_interface;

public interface Volume {
	
	public void up();
	
	public void down();
	
	

}
