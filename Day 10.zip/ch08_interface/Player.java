package ch08_interface;

public class Player implements Power, Volume{
	
	
	public void on() {
		System.out.println("전원 on");
	}
	
	public void off() {
		System.out.println("전원 off");
	}
	
	public void up() {
		System.out.println("볼륨 up");

	}
	
	public void down() {
		System.out.println("볼륨 down");

	}
	
	//객체를 못만드는것이지 변수는 상관 x

}
