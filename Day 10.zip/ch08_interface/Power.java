package ch08_interface;

public interface Power {
	
	public void on();
	
	public void off();
	
	

}
