package ch07_interface;

/*
 * interface
 * - 100% 순수한 추상 클래스
 * - class 대신 interface를 사용해서 정의
 */


public interface Tools {
	
	// interface안의 모든 멤버필드는 자동으로 public static final임
	int A = 1;
	public static final int B = 2;
	
	//public Tools(){} 
	
	public abstract void abstractMethod();
	
	public static void staticMethod() {
		System.out.println("-staticMethod-");
	}
	default void defaultMethod() {
		System.out.println("-defaultMethod-");
	}

}
