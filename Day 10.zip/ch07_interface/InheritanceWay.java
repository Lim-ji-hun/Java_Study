package ch07_interface;

class TestA {}

interface InterA {}

class TestB extends TestA {}

class TestZ extends TestB {}

class TextC implements InterA {}

class TextD {}

//class testE extends TestA, TestD{} 한번에 여러개의 클래스를 상속 못 받음

class TextE extends TestA implements InterA{} //인터페이스 하나 클래스 하나를 상속받는건 동시에 가능

interface InterB extends InterA {}

class TestF implements InterA, InterB {}



public class InheritanceWay {

	
	

}
