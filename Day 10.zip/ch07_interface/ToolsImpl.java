package ch07_interface;

public class ToolsImpl implements Tools {

	public void abstractMethod() {
		
	}
	
}
