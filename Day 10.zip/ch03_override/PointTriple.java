package ch03_override;

/*
 * 오버라이드 (override)
 * - 상속받는 자식클래스에서 부모클래스의 메서드를 재정의 하는것 
 * - 메서드의 형태는 부모클래스의 메서드와 동일해야 함
 * - 접근제한자는 동일하거나 더 넓은 범위여야 한다
 * 
 */

public class PointTriple extends Point {
	
	private int pz;
	
	public PointTriple() {
		System.out.println("-PointTriple-");
	}
	
	public PointTriple(int px, int py, int pz) {
		super(px, py);
		System.out.println("-PointTriple(int px, int py, int pz)-");
		this.pz = pz;
	}
	
	public void threePoint() {
		System.out.println("좌표 x : " + getPx() + "좌표 y : " + getPy() + "좌표 z : " + pz);
	}
	//override
	public final void info() { //final을 붙이면 상속받는 쪽에서 오버라이드 불가
		System.out.println("-PointTriple Info()-");
		System.out.println("좌표 x : " + getPx() + "좌표 y : " + getPy() + "좌표 z : " + pz);
	}
	
}
