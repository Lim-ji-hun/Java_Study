package ch03_override;

public class PointTest {
	public static void main(String[] args) {
		
		Point pointA = new Point(10, 20);
		pointA.info();
		
		System.out.println();
		
		PointTriple ptA = new PointTriple();
		//자식의 클래스를 생항하면 부모 클래스가 먼저 샐행됨
		
		System.out.println();
		
		PointTriple ptB = new PointTriple(30, 40, 50);
		ptB.threePoint();
		
		System.out.println();
		
		ptB.info();
		
	}

}
