package ch03_override;

public class Point {
	
	private int px;
	private int py;
	
	public Point() {
		System.out.println("-point()-");
		this.px = this.py = 0;
	}
	public Point(int px, int py) {
		System.out.println("-point(int px, int py)-");
		this.px = px;
		this.py = py;

	}
	public int getPx() {return px;}
	public void setPx(int px) {this.px = px;}
	
	public int getPy() {return py;}
	public void setPy(int py) {this.py = py;}
	
	public void info() {
		System.out.println("좌표 X : " + px + " - 좌표 Y " + py);
	}
	
	
	
}
