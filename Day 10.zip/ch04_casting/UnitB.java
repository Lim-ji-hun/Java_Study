package ch04_casting;

public class UnitB extends Base{
	
	
	
	
}
