package ch04_casting;

public class Base {
	
	private String item;
	
	public Base() {
		item = "기본 무기";
		
	}
	
	public void baseAttack() {
		System.out.println(item + " 사용");
	}

}
