package ch04_casting;

/*
 * instanceof 연산자
 * - 참조 변수가 현재 사용중인 객체 타입을 확인할때 사용
 *   타입이 같으면 true 다르면 false
 * 
 */

public class Casting {
	
	public static void main(String[] args) {
		
		UnitA userA = new UnitA();
		userA.baseAttack();
		userA.unitAttack();
		System.out.println();
		
		Base base = userA; // up casting : 자동
		base.baseAttack();
		//base.unitAttack(); error
		System.out.println();
		
		userA = (UnitA)base; //down casting : 변환타입을 지정
		userA.baseAttack();
		userA.unitAttack();
		System.out.println();
		
		if(base instanceof UnitA) {
			userA = (UnitA)base;
		}
		
		
		if(base instanceof UnitB) {
			UnitB userB = (UnitB)base;
		}else {
			System.out.println("UnitB타입이 아님");
		}
		
	}

}
