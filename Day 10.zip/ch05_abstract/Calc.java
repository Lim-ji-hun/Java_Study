package ch05_abstract;

/*
 * 추상 클래스
 * - 상속받을class에서 구현 할 특성을 정의한 class
 * - 객체를 생성할 수 없음
 * 
 * 추상메서드
 * - 추상 클래스 안에서 기능을 정의하지 않은 메서드
 * - 상속받는 자식클래서에서 반드시 override를 해야함
 * 
 */


public abstract class Calc {
	
	protected int dataA;
	protected int dataB;
	
	public abstract void showData(); // 추상메서드는 기능구현을 하면 안됨
	
	public void typeInfo() {
		System.out.println("- Calc class -");
	}
}//Calc class

class Add extends Calc {
	
	public Add(int a, int b) {
		dataA = a;
		dataB = b;
	}
	
	public void showData(){
		
		System.out.println(dataA + " + " + dataB + " = " + (dataA + dataB));
		
	}
	
}//Add class



class Sub extends Calc {
	
	public Sub(int a, int b) {
		dataA = a;
		dataB = b;
	}
	
	public void showData(){
		
		System.out.println(dataA + " - " + dataB + " = " + (dataA - dataB));
		
	}
	
}//Sub class
