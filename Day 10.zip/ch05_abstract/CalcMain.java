package ch05_abstract;

public class CalcMain {
	
	public static void main(String[] args) {
		
		Add add = new Add(11, 22);
		add.showData();
		
		System.out.println();
		
		Sub sub = new Sub(33, 44);
		sub.showData();
		
		System.out.println();
		
		//Calc calc = new Calc(); error -> 추상클래스는 객체생성 불가
		
		Calc calc = null;
		calc = add;
		calc.showData();
		
		calc = sub;
		calc.showData();
		
		System.out.println();
		
		Calc run = null;
		int a = 123;
		int b = 45;
		char opt = '+';
		
		switch(opt) {
		case '+':
//			Add tmp = new Add(a, b);
//			run = tmp;
			run = new Add(a, b);
			break;
		case '-':
			run = new Sub(a, b);
			break;
		
		}
		
		if(run != null) {
			run.showData();
		}
		
		
		
	}

}
