package ch10_interface;

public class Printer implements Print{
	
	
	public void printSRART() {
		System.out.println("프린트 출력 시작");
	}
	
	public void printCANCEL() {
		System.out.println("프린트 출력 취소");
	}
	
	

}
