package ch10_interface;

public class PrintMain {
	
	public static void main(String[] args) {
		
		PrintMachine pm = new PrintMachine();
		
		boolean run = true;
		while(run) {
			run = pm.modeSelect();
			
		}
		System.out.println("- Power OFF -");
		
		
		
		
	}

}
