package ch10_interface;

public class Scan implements Print {
	
	public void printSRART() {
		System.out.println("스캔 시작");
	}
	
	public void printCANCEL() {
		System.out.println("스캔 취소");
	}

}
