package ch10_interface;

public interface Print {
	
	int START =1;
	int CANCEL = 2;
	
	public void printSRART();
	
	public void printCANCEL();
	
	
}
