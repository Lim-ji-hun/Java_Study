package ch10_interface;

import java.util.Scanner;

public class PrintMachine {
	
	private Scanner scanner;
	private Print current;
	private int device;
	private Printer printer;
	private Scan scan;
	
	public PrintMachine() {
		scanner = new Scanner(System.in);
		printer = new Printer();
		scan = new Scan();
		device = 1;
		current = printer;
		
	}
	
	public boolean modeSelect() {
		
		System.out.println("1.장치 선택  2.인쇄/취소 >>");
		int mode = scanner.nextInt();
		
		switch(mode) {
		case 1:
			selectDevice();
			break;
		case 2:
			printRun();
			break;
		case 0:
			return false;
			
		}
		System.out.println();
		return true;

	}
	
	public void selectDevice() {
		
		System.out.println("1.프린터 2.스캔어 >> ");
		device = scanner.nextInt();
		
		if(device == 1)
			current = printer;
		else if(device == 2)
			current = scan;
		
	}
	
	public void printRun() {
		
		System.out.println("1.시작  2.취소 >> ");
		int select = scanner.nextInt();
		
		switch(select) {
		case Print.START:
			current.printSRART();
			break;
		case Print.CANCEL:
			current.printCANCEL();
			break;
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
