package ex04;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MenberServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		String name = request.getParameter("userName");
		String gender = request.getParameter("gender");
		String[] arrHobby = request.getParameterValues("hobby");
		String[] arrSubject = request.getParameterValues("subject");
		
		String hobby = "";
		if(arrHobby != null) {
			for(int i=0 ; i<arrHobby.length ; i++) {
				if(arrHobby[i] != null) {
					hobby += arrHobby[i] + "";
				}
			}
		}
		
		String subject = "";
		if(arrSubject != null) {
			for(int i=0 ; i<arrSubject.length ; i++) {
				if(arrSubject[i] != null) {
					subject += arrSubject[i] + "";
				}
			}
		}
		
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		
		out.println("<title>입력 내용</title>");
		
		out.println("<style>");
		out.println("li {color: gray; font-size: 24px; font-weight: bold;");
		out.println("</style>");
		
		out.println("</head>");
		out.println("<body>");
		
		out.println("<h2>입력 내용</h2>");
		
		out.println("<ul>");
		
		out.println("<li>" + name + "</li>");
		out.println("<li>" + gender + "</li>");
		out.println("<li>" + hobby + "</li>");
		out.println("<li>" + subject + "</li>");
		
		out.println("</ul>");
		
		out.println("<br/><br/>");
		out.println("<a href='javascript:history.back()'> 이전페이지 </a>");
		
		out.println("</body>");
		out.println("</html>");
		
	}
	
	
}
