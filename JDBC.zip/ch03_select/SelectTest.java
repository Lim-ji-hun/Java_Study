package ch03_select;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

class Select {
	
	
	String url = "jdbc:oracle:thin:@localhost:1521:xe"; 
	String id = "DBTEST";
	String pwd = "a1234";
		
	public Select() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
			}
		} //Select()
		
	public Connection getConnection() {
		Connection con = null;
			
		try {
			con = DriverManager.getConnection(url, id, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
			
	} //getConnection()
	
	public void selectData() {
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet res = null;
		
		try {
			
			String sql = "Select * from member";
			con = this.getConnection();
			pstmt = con.prepareStatement(sql);
			res = pstmt.executeQuery();
			
			while(res.next()) {
				
				String name = res.getString("name");
				int age = res.getInt("age");
				double height = res.getDouble("height");
				String logtime = res.getString("logtime");
				System.out.println(name + "\t" + age + "\t" + height + "\t" +logtime);
				
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(res != null) res.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
}//class Select

public class SelectTest {
	
	public static void main(String[] args) {
		
		Select db = new Select();
		db.selectData();
		
		
	}

}
