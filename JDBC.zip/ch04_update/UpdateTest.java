package ch04_update;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;



class update{
	
	String url = "jdbc:oracle:thin:@localhost:1521:xe"; 
	String id = "DBTEST";
	String pwd = "a1234";
		
	public update() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
			}
		} //Select()
		
	public Connection getConnection() {
		Connection con = null;
			
		try {
			con = DriverManager.getConnection(url, id, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
			
	} //getConnection()
	
	public void updateData()  {
		Scanner scanner = new Scanner(System.in);

		System.out.print("이름 > ");
		String name = scanner.next();

		Connection con = null;
		PreparedStatement pstmt = null;
		int res = 0;
		
		try {
			
			// 쿼리 문자열
			String sql = "update member set age=age+1 where name=?";
			con = this.getConnection();			   // connection 객체 생성
			pstmt = con.prepareStatement(sql); // 쿼리문 실행 객체 생성         // 쿼리문 완성
			pstmt.setString(1, name);
			res = pstmt.executeUpdate();             // 쿼리문 실행

			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println(res + "로 수정 되었습니다");
	}
}

public class UpdateTest {
	public static void main(String[] args) {
		
		update db = new update();
		db.updateData();
		
	}

}





































