package ch02_insert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

/*
 * # JDBC 절차
 * 1. DriverManager에 해당 DBMS Driver 등록
 * 2. Driver로 부터 Connection instance 획득
 * 3. Connection 객체의 prepareStatement()메서드를 사용하기 위한 PreparedStatement 객체 생성
 *    - 각각의 인수에 대해 위치홀더(?)를 사용해서 SQL 문장을 정의함
 * 4. 쿼리 실행
 * 
 * # PreparedStatement : java.sql.PreparedStatement
 * - 쿼리 실행을 위한 class
 * - 쿼리 실행 메서드 
 *   > int executeUpdate() : insert, delete, update 문을 실행해서 성공한 행의 수를 반환
 *     ResultSet executeQuery() : select 문을 실행한 결과의 테이블 내용을 ResultSet에 담아서 반환
 * 
 */

class Insert{
	//연결정보
	String url = "jdbc:oracle:thin:@localhost:1521:xe"; 
	String id = "DBTEST";
	String pwd = "a1234";
	
	public Insert() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("로딩 성공");
		} catch (Exception e) {
			//System.out.println("로딩 실패");
			e.printStackTrace();
		}

	} //Insert()
	
	public Connection getConnection() {
		Connection con = null;
		
		try {
			// DB 연결 객체 생성
			con = DriverManager.getConnection(url, id, pwd);
			//System.out.println("연결 성공");
		} catch (Exception e) {
			//System.out.println("연결 실패");
			e.printStackTrace();
		}
		return con;
		
		
	} //getConnection()
	
	public void insertData() {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("이름 > ");
		String name = scanner.next();
		System.out.print("나이 > ");
		int age = scanner.nextInt();
		System.out.print("키 > ");
		double height = scanner.nextDouble();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		int res = 0;
		
		try {
			
			// 쿼리 문자열
			String sql = "insert into member values(?, ?, ?, sysdate)";
			con = getConnection();			   // connection 객체 생성
			pstmt = con.prepareStatement(sql); // 쿼리문 실행 객체 생성
			pstmt.setString(1, name);          // 쿼리문 완성
			pstmt.setInt(2, age);
			pstmt.setDouble(3, height);
			res = pstmt.executeUpdate();             // 쿼리문 실행

			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				//사용 자원 종료
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		System.out.println(res + "개의 행이 추가 되었습니다");
		
	} //insertData()
	
} //class Insert
		

public class InsertTest {
	
	public static void main(String[] args) {
		
		Insert db = new Insert();
		db.insertData();
		
	}

}
