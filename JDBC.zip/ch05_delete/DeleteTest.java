package ch05_delete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;


class Delete{
	String url = "jdbc:oracle:thin:@localhost:1521:xe"; 
	String id = "DBTEST";
	String pwd = "a1234";
		
	public Delete() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
			}
		} 
		
	public Connection getConnection() {
		Connection con = null;
			
		try {
			con = DriverManager.getConnection(url, id, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
			
	} 
	
	public void DeleteData()  {
		Scanner scanner = new Scanner(System.in);

		System.out.print("이름 > ");
		String name = scanner.next();

		Connection con = null;
		PreparedStatement pstmt = null;
		int res = 0;
		
		try {
			
			String sql = "Delete member where name=?";
			con = this.getConnection();			
			pstmt = con.prepareStatement(sql); 
			pstmt.setString(1, name);
			res = pstmt.executeUpdate();   

			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println(res + "가 삭제됨");
	}
}

public class DeleteTest {
	public static void main(String[] args) {
		
		Delete db = new Delete();
		db.DeleteData();
		
	}


}
