package ch01_driver;

import java.sql.Connection;
import java.sql.DriverManager;

/*
 * # JDBC(Java Database Connectivity)
 * - Java와 Database 연동을 위한 프로그래밍 API
 * 
 * # JDBC 드라이버
 * - DBMS 마다 별도의 드라이버가 필요
 * - 프로젝트의 build path를 사용해서 추가함
 * - build path -> Configure Build Path -> Libraries -> Add Exteranl JARs -> object8.jar 추가
 * 
 * # jdbc 드라이버 클래스
 * - oracle.jdbc.OracleDriver
 * 
 * # Oracle Database URL
 * - jdbc:oracle:driver_type:@host_name(ip):port:service_name
 *   jdbc:oracle:thin:@localhost:1521:xe
 * 
 * 
 * # 테스트계정 생성
 * - system 계정 연결해서 DBTEST 계정 생성
 *  CREATE USER DVTEST IDENTIFIED BY a1234;
 *  
 *  GRANT CONNECT, RESOURCE TO DBTEST
 *  
 *  ALTER USER DBTEST DEFAULT TABLESPACE USERS;
 *  ALTER USER DBTEST QUOTA UNLIMITED ON USERS;
 *  
 *  - DBTEST 계정에 member 테이블 생성
 *  CREATE TABLE member(
 *  name VARCHAR2(20) NOT NULL,
 *  age NUMBER(3),
 *  height NUMBER(10, 2),
 *  logtime DATE
 *  );
 *  
 *  
 */

public class DriverConnect {
	public static void main(String[] args) {
		
		// jdbc 드라이버 로딩
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("로딩 성공");
		} catch (Exception e) {
			System.out.println("로딩 실패");
			e.printStackTrace();
			
		}
		
		//연결정보
		String url = "jdbc:oracle:thin:@localhost:1521:xe"; 
		//String url = "jdbc:oracle:thin:@192.168.12.226:1521:xe"; 
		String id = "DBTEST";
		String pwd = "a1234";
		
		Connection con = null;
		try {
			// DB 연결 객체 생성
			con = DriverManager.getConnection(url, id, pwd);
			System.out.println("연결 성공");
		} catch (Exception e) {
			System.out.println("연결 실패");
			e.printStackTrace();
			
			
			
		}

		
	}
	

}
