package nio;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class nio_client {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		Socket socket = null;
		BufferedWriter write = null;

		try {
			socket = new Socket("192.168.12.226", 11000);
			
			write = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			System.out.print("전송 > ");
			String message = scanner.nextLine();
			
			write.write(message);
			write.flush();
			

			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(write != null) write.close();
				if(socket != null) socket.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
	}
	
}
