package nio;
/*
TCP/IP 방식으로 연결되는 server, client 를 구현하세요

1. 프로젝트명 : QuizNio , packege 명 : nio

   class명은 자유롭게 설정하고, server, client 각각 다른 class 파일로 작성합니다

2. 자신의 ip를 사용하고, port 11000 번을 사용합니다

3. client 가 연결되면, server 로 하나의 문자열을 전송할 수 있어야 합니다

4. client 가 전송한 문자열을 서버에서 출력하고, 종료합니다

   > 전송, 출력 내용을 캡처하세요

5. client, server 연결에서 사용한 통로는 finally를 사용해서 닫아야 합니다
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class nio_server {
	public static void main(String[] args) {
		
		ServerSocket server = null;
		Socket socket = null;
		BufferedReader read = null;
		
		
		try {
			server = new ServerSocket(11000);
			System.out.println("- Server 준비 -");
			socket = server.accept();
			
			read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			String Message = read.readLine();
			System.out.println("출력 : " + Message);
			
			System.out.println("종료");
			
			
		} catch (Exception e) {
			e.printStackTrace();	
		} finally {
			try {
				if(read != null) read.close();
				if(socket != null) socket.close();
				if(server != null) server.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
