package dto;

import javax.xml.crypto.Data;

/*
 * CREATE TABLE member(
 * name VARCHAR2(20) not null,
 * age MEMBER,
 * height MUNBER(10, 2),
 * logtime DATE
 * );
 */
public class MemberDTO {

	private String name;
	private int age;
	private double height;
	private Data date;
	
	public MemberDTO() {}
	
	public MemberDTO(String name, int age, double height) {
		super();
		this.name= name;
		this.age= age;
		this.height= height;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public Data getDate() {
		return date;
	}

	public void setDate(Data date) {
		this.date = date;
	}
	
	
}
