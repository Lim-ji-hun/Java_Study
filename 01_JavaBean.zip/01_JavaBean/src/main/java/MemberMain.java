import dao.MemberDAO;
import dto.MemberDTO;

public class MemberMain {

	public static void main(String[] args) {
		
		MemberDAO dao = new MemberDAO();
		//dao.getConnection();
		
		//dao.insert(new MemberDTO("testA", 20, 178.9));
		
		//dao.select();
		
		//dao.update(new MemberDTO("testA", 100, 200));
		//dao.select();
		
		//dao.delete("testA");
		//dao.select();
			
		
		//----------------------------------------
		
		// 1.추가  2.삭제  3.수정  4.확인
		// - 필요한 데이터는 Scanner 로 입력받아서 처리하세요
		MemberController controller = new MemberController();
		controller.menu();
		
		
	}
	

}
