CREATE TABLE member(
name VARCHAR2(20) NOT NULL,
age NUMBER(3),
height NUMBER(10, 2),
logtime data);

desc member;
select * from member;

