package ch09_final;

public class FinalTest {
	
	public static void main(String[] args) {
		
		final double PI;
		PI = 3.141592;
		//PI = 3.14; Error -> final 설정된 값은 변경불가
		
		final int TEN = 10;
		//TEN = 1; Error
		
		//final 선언된 값은 대문자로만 작성하자
	}

}
