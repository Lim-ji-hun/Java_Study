package ch09_final;

public class ExFinal {
	
	private int value;
	private final int A;
	private final int B = 2;
	
	private static final int c;
	private static final int D = 4;	
	
	
	
	public ExFinal() {
		A = 1;
	}
	
	static {
		c = 3;
	}
	


}
