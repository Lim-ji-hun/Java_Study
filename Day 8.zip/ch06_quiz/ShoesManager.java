package ch06_quiz;

public class ShoesManager {
	public static void main(String[] args) {
		
		Shoes ShoesA = new Shoes();
		ShoesA.info();
		
		System.out.println();
		
		ShoesA.setcomp("아디다스");
		ShoesA.setname("독일군");
		ShoesA.setsize(270);
		ShoesA.setprise(180000);
		
		ShoesA.info();
		
		System.out.println();
		
		Shoes ShoesB = new Shoes("나이키", "에어맥스", 265, 120000);
		ShoesB.info();
	}
}
