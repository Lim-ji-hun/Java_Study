package ch06_quiz;

/*
 * 신발 정보를 가지는 Shoes class 를 정의하고, ShoesManager class 에서 테스트 하세요
 * - 제조회사, 모델명, 사이즈, 가격의 관리가 가능합니다
 * - 생성자 2개 이상,  getter/setter 가 있어야 합니다
 * - 사이즈 : 200 ~ 300 mm 만 가능합니다
 *   가격   : -(minus) 값은 사용할 수 없습니다
 * 
 */


public class Shoes {
	
	private String comp;
	private String name;
	private int size;
	private int prise;
	
	public Shoes() {
		comp = "none";
		name = "none";
		size = 0;
		prise = 0;
	}
	
	public Shoes(String comp, String name, int size, int prise){
		
		this.comp = comp;
		this.name = name;
		this.size = size;
		this.prise = prise;
		
	}
	
	public String getcomp() {return comp;}
	public void setcomp(String comp) {
		this.comp = comp;
	}
	
	public String getname() {return name;}
	public void setname(String name) {
		this.name = name;
	}

	public int getsize() {return size;}
	public void setsize(int size) {
		if(size >= 200 && size <= 300) {
			this.size = size;
		} else {System.out.println("해당 사이즈는 없습니다");}
	}
	
	public int getprise() {return prise;}
	public void setprise(int prise) {
		if(prise >= 0) {
			this.prise = prise;
		} else {System.out.println("해당 가격의 제품은 없습니다");}
	}
	
	void info() {
		System.out.println("--신발 정보--");
		System.out.println("제조회사 : " + comp);
		System.out.println("모델명 : " + name);
		System.out.println("사이즈 : " + size + "mm");
		System.out.println("가격 : " + prise + "원");
	}
	
	
	
}
