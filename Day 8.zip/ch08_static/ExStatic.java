package ch08_static;

public class ExStatic {
	
	public static int staValue; //static : 코드 내에서 다같이 사용하는 것 공용 코드
 	private int priValue;
 	
 	static {
 		System.out.println("- static area -");
 		staValue = -1;
 		//priValue = 0; Error - static을 제외한 값은 들어가면 안됨
 	}
	
	public ExStatic() {
		++staValue;
		++priValue;
		System.out.println("staValue : " + staValue + " - priValue : " + priValue);
		
	}
	
	public static void staticMethod() {
		System.out.println("- staticMethod -");
		System.out.println("staValue : " + staValue);
		// System.out.println("priValue : " + priValue); error
		//static으로 선언된 값만 들어갈수있음
		int a = 1; // 해당 메서드가 활성화 되면 사용하기에 이러한 것은 사용 가능
	}
	
	public void info() {
		System.out.println("staValue : " + staValue);
		System.out.println("priValue : " + priValue);
	}
	
	static {
 		System.out.println("- static area2 -");
 		//static은 해당 클래스가 로드되는 순간 가장 먼저 실행됨
 	}

}
