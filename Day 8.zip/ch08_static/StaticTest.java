package ch08_static;

public class StaticTest {
	
	public static void main(String[] args) {
		
		ExStatic.staValue = 0;//객체랑 상관 없이 클래스명으로 직접 사용할 수 있음
		ExStatic.staticMethod();
		
		ExStatic esA = new ExStatic();
		ExStatic esB = new ExStatic();
		
		esA.staValue = 10; //참조변수로 사용하는 것은 됨
		
	}

}
