package ch08_accessB;

import ch07_accessA.First;
//import ch07_accessA.Second; Error -> public 없음


public class AreaTwo {
	
	public static void main(String[] args) {
		
		First firstB = new First();
		//package가 다르면 public 만 가능
		firstB.pubData = 1;
		//firstB.proData = 2; Error
		//firstB.defData = 3; Error
		//firstB.priData = 4; Error
		//firstB.defaultMethod(); Error
		firstB.publicMethord();
		
		System.out.println();
		
		
		
	}
	

}
