package ch04_constructor;

/*
 * Member class를 정의라고 MemberManager에서 테스트
 * - 회원 ID, 이름, 나이의 관리가 가능
 *   > 이름은 10글자까지
 *     나이는 0~130 사이
 * - 생성자는 2개 이상 정의
 */

public class Member {
	
	private String ID;
	private String name;
	private int old;
	
	public Member(String _ID, String _name, int _old) {
		System.out.println("--회원 정보--");
		ID = _ID;
		name = _name;
		old = _old;
		
	}
	
	public String getID() {
		return ID;
	}
	
	public void setID(String _ID) {
		ID = _ID;
	}
	
	public String getname() {
		return name;
	}
	
	public void setname(String _name) {
		if(_name.length() <= 10 && _name.length() >= 2) {
			name = _name;
		} else {
			System.out.println("이름은 2 ~ 10글자만 가능");
		}	
	}
	
	public int getold() {
		return old;
	}
	public void setold(int _old) {
		if(_old >= 0 && _old <=130) {
			old = _old;
		} else {
			System.out.println("잘못된 값입니다");
		}
		
	}
	
	void info() {
		System.out.println("ID : " + ID);
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + old);
	}

}
