package ch04_constructor;

public class MemberManager {
	public static void main(String[] args) {
		
		Member MemberA = new Member("asd", "가나다", 100);
		
		MemberA.info();		
	}
}
