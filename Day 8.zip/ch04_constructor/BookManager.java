package ch04_constructor;



public class BookManager {
	public static void main(String[] args) {
		
		Book bookA = new Book();
		
		Book bookB = new Book("JAVA", "제임슨", 'A', 20000);
		
		bookB.info();
		
		
	}

}
