package ch04_constructor;
/*
 * 생성자 ( constructor )
 * - class 명과 동일한 이름을 사용하고 객체를 초기화하는 용도로 사용
 * - 생성자를 정의하지 않으면 멤버필드를 기본값으로 초기화하는 기본생성자가 자동으로 만들어져 실행 됨
 * - 생정자는 매개변수를 사용할 수 있기 때문에 오버로딩이 가능하다
 * - 생성자를 하나라고 정의하면 기본생성자가 자동으로 만들어지지 않음
 * - 반환타입을 정의하지 않음
 */ 
public class Book {
	
	private String name;
	private String writer;
	private char where;
	private int prise;
	
	public Book() {
		System.out.println("- Book() -");
	}
	
	public Book(String _name, String _writer, char _where, int _prise) {
		System.out.println("--String _name, String _writer, char _where, int _prise--");
		name = _name;
		writer = _writer;
		where = _where;
		prise = _prise;
		
	}
	
	public String getname() {
		return name;
	}
	
	public void setname(String _name) {
		name = _name;
	}
	
	public String getwriter() {
		return writer;
	}
	
	public void setwriter(String _writer) {
		if(_writer.length() <= 10 && _writer.length() >= 2) {
			writer = _writer;
		} else {
			System.out.println("이름은 2 ~ 10글자만 가능");
		}	
	}
	
	public char getwhere() {
		return where;
	}
	
	public void setwhere(char _where) {
		if(_where == 'A' || _where == 'B' || _where == 'C') {
			where = _where;
		} else {
			System.out.println("A, B, C 만 가능");
		}	
	}
	
	public int getprise() {
		return prise;
	}
	
	public void setprise(int _prise) {
		if(_prise >= 0) {
			prise = _prise;
		} else {
			System.out.println("+(plus) 만 가능 ");
		}
		
	}
	
	
	void info() {
		System.out.println("---책 정보---");
		System.out.println("책 이름 : " + name);
		System.out.println("글쓴이 : " + writer);
		System.out.println("진열위치 : " + where);
		System.out.println("가격 : " + prise + "원");
	}
	

}
