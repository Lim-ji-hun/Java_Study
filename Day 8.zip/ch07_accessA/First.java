package ch07_accessA;

public class First {
	
	public int pubData;
	protected int proData;
	int defData;
	private int priData;
	
	void defaultMethod() {}
	
	public void publicMethord() {}
	
	
	
	

}
