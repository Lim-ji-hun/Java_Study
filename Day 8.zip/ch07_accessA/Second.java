package ch07_accessA;

class Second {
	
	public int pubData;
	protected int proData;
	int defData;
	private int priData;
	
	void defaultMethod() {}
	
	public void publicMethord() {}

}
