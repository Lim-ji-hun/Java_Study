package ch07_accessA;

/*
 * 접근제한자
 * - 다른 class에서 class또는 class멤버의 접근을 허용할지 결정
 *   > public : 모든class에서 접근이 가능합
 *     protected : 같은 package, 상속받는 하위 class에서 접근이 가능
 *     default : 같은 package 내에서만 접근이 가능
 *     private : class안에서만 접근이 가능하고 외부에서는 접근할 수 없음
 *     
 *                class내부  같은package  하위class  다른package                        
 *   public          0          0          0          0       
 *   protected       0          0          0          X
 *   default         0          0          X          X 
 *   private         0          X          X          X 
 */

public class AreaOne {
	public static void main(String[] args) {
		
		First firstA = new First();
		firstA.pubData = 1;
		firstA.proData = 2;
		firstA.defData = 3;
		//firstA.priData = 4; Error
		firstA.defaultMethod();
		firstA.publicMethord();
		
		System.out.println();
		
		Second secondA = new Second();
		secondA.pubData = 1;
		secondA.pubData = 1;
		secondA.proData = 2;
		secondA.defData = 3;
		//secondA.priData = 4; Error
		secondA.defaultMethod();
		secondA.publicMethord();

		
	}
}
