package ch05_this;

/*
 * this 
 * - class안에 instance 멤버를 가르키는 참조변수
 * 
 * this()
 * - 생성자에서 this()를 이용해서 다른 생성자를 호출할 수 있다
 * - 생성자의 첫번째 라인에서만 사용이 가능
 */

public class Member {
	
	private String ID;
	private String name;
	private int old;
	
	public Member(String ID, String name, int old) {
		System.out.println("--회원 정보--");
		this.ID = ID;
		this.name = name;
		this.old = old;
		
	}
	
	public Member() {
		System.out.println("--aaaaaaaaa--");
		ID = "none";
		name = "none";
		old = 1000;
	}
	
	public Member(String id) {
		this();
		System.out.println("--ggggggg--");
		this.ID = id;
		name = "none";
		old = 0;
	}
	
	public String getID() {
		return ID;
	}
	
	public void setID(String ID) {
		this.ID = ID;
	}
	
	public String getname() {
		return name;
	}
	
	public void setname(String name) {
		if(name.length() <= 10 && name.length() >= 2) {
			this.name = name;
		} else {
			System.out.println("이름은 2 ~ 10글자만 가능");
		}	
	}
	
	public int getold() {
		return old;
	}
	public void setold(int old) {
		if(old >= 0 && old <=130) {
			this.old = old;
		} else {
			System.out.println("잘못된 값입니다");
		}
		
	}
	
	void info() {
		System.out.println("ID : " + ID);
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + old);
	}

}
