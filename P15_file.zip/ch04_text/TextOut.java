package ch04_text;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class TextOut {
	
	public static void main(String[] args) throws IOException {
		
		File path = new File("D:" + File.separator + "P15_file");
		File mf = new File(path, "sentence.txt");
		
		if(mf.createNewFile()) {
			System.out.println(mf.getName() + "파일 생성");
		} 
		
		FileWriter fw = null;
		BufferedWriter bw = null;
		PrintWriter pw = null;
		
		
		try {
			
			fw = new FileWriter(mf);      // 텍스트 기반 파일 문자 기록
			bw = new BufferedWriter(fw);  // 텍스트 기반 데이터를 버퍼에 저장해서 처리
			pw = new PrintWriter(bw);     // 문자열, 숫자 등을 텍스트 형식으로 쓸수있는 메서드 제공
			
			pw.println("데이터 처리를 편하게 할수있어요");
			pw.println("완료");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			pw.close();
		}
		
	}

}
