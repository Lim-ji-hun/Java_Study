package ch04_text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class TextIn {
	
	public static void main(String[] args) throws IOException {
		
		File path = new File("D:" + File.separator + "P15_file");
		File mf = new File(path, "sentence.txt");
		
		if(mf.createNewFile()) {
			System.out.println(mf.getName() + "파일 생성");
		} 
		
		FileReader fr = null;
		BufferedReader br = null;
		

		
		try {
			
			fr = new FileReader(mf);
			br = new BufferedReader(fr);//한번에 많은 데이터를 사용할려고buffer을 씀
			
			while(true) {
				String rd = br.readLine();
				if(rd == null)//문자는 맨 마지막 더이상 읽을게 없는것이 null임
					break; 
				System.out.println(rd);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			br.close();
		}
		
	}

}
