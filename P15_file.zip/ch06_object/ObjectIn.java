package ch06_object;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectIn {
	
	public static void main(String[] args) {
		
		File path = new File("D:\\P15_file\\objectFile.txt");
		File mf = new File(path, "Unit.txt");
		
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		ObjectInputStream ois = null;
		
		
		try {
			
			fis = new FileInputStream(mf);
			bis = new BufferedInputStream(fis);
			ois = new ObjectInputStream(bis);
			
			Unit unit = (Unit)ois.readObject();
			System.out.println(unit);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(ois != null) ois.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
	}

}
