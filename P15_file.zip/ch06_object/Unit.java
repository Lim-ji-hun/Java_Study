package ch06_object;

import java.io.Serializable;

/*
 * 직렬화
 * - 객체 정보를 모아서 바이트 형태로 변환하는 것
 * 
 */

// 직렬화 자격을 획득하기 위해서는 java.io.Serializable을 상속 받는다
public class Unit implements Serializable {
	
	//  serialVersionUID
	// - 같은 class인지 확인하는 직렬화 식별자
	private static final long serialVersionUID = 1L;//임의로 설정 
	private String id;
	private int lv;
	
	public Unit(String id, int lv) {
		this.id = id;
		this.lv = lv;
	}
	
	public String toString() {
		return "ID : " + id + " - lv : " + lv;
	}
	

}
