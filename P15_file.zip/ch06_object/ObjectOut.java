package ch06_object;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectOut {
	
	public static void main(String[] args) throws IOException {
		
		File path = new File("D:\\P15_file\\objectFile.txt");
		if(path.exists() == false) {
			path.mkdir();
			System.out.println("없으니깐 내가 만듬ㅇㅇ");
			}
		
		File mf = new File(path, "Unit.txt");
		if(mf.createNewFile()) {
			mf.mkdir();
			System.out.println(mf.getName() + "파일 생성");
			}
		
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
		ObjectOutputStream oos = null;
		
		Unit unit = new Unit("u001", 10);
		
		try {
			
			fos = new FileOutputStream(mf);
			bos = new BufferedOutputStream(fos);
			oos = new ObjectOutputStream(bos);
			
			oos.writeObject(unit);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(oos != null) oos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
	}

}
