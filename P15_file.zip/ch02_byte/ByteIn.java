package ch02_byte;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ByteIn {
	
	public static void main(String[] args) throws IOException {
		
		File path = new File("D:" + File.separator + "P15_file");
		File mf = new File(path, "test.txt");
		
		if(mf.createNewFile()) {
			System.out.println(mf.getName() + "파일 생성");
		} 
		
		//데이터 전송 통로 생성
		FileInputStream fis = null;
		try {
			
			fis = new FileInputStream(mf);//데이터 전송 통로 생성
			while(true) {
				int rd = fis.read();
				if(rd == -1)//파일의 값을 가겨오다가 다 가져와서 더이상 가져올수없으면 -값을 가져옴(byte값임)
					break;
				System.out.print((char)rd);
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			fis.close();
		}
		
		
	}

}
