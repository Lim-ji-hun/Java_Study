package ch02_byte;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteOut {
	
	public static void main(String[] args) throws IOException {
		
		File path = new File("D:" + File.separator + "P15_file");
		File mf = new File(path, "test.txt");
		
		if(mf.createNewFile()) {
			System.out.println(mf.getName() + "파일 생성");
		} 
		
		//데이터 전송 통로 생성
		FileOutputStream fos = null;
		
		try {
			
			fos = new FileOutputStream(mf, true); //데이터 전송 통로 생성  defalse가 덮어쓰기 true가 기존내용을 남겨두고 추가 쓰기
			
			String data = "test data...";
			byte[] wd = data.getBytes();
			fos.write(wd);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			fos.close();
		}	
		
	}
	
}
