package ch01_file;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Exfile {
	
	public static void main(String[] args) throws IOException {
		
		// 폴더 경로를 가지는 객체 생성
		//File path = new File("D:\\P15_file");
		
		//폴더 구별자 : File.separtor
		File path = new File("D:" + File.separator + "P15_file");
		
		//폴더가 있는지 확인
		if(path.exists() == false) {
			path.mkdir();
			System.out.println("없으니깐 내가 만듬ㅇㅇ");
		}
		
		// 폴더 위치, 파일명을 가지는 객체 생성
		File data = new File(path, "test.txt");
		
		//경로에 파일이 없으면 생성
		if(data.createNewFile()) {
			System.out.println(data.getName() + "파일 생성");
		} else {
			System.out.println(data.getName() + "중복 파일");
		}
		
		System.out.println();
		
		SimpleDateFormat sdf = 
				new SimpleDateFormat("yyyyMMdd-HHmmss");
		
		System.out.println("- 파일 정보 -");
		System.out.println("절대 경로 : " + data.getAbsolutePath());//경로
		System.out.println("생성 일자 : " + new Date(data.lastModified()));//만들어 지거나 수정된 최종일자
		System.out.println("생성 일자 : " + sdf.format(new Date(data.lastModified())));//만들어 지거나 수정된 최종일자
		System.out.println("파일 크기 : " + data.length());
		
		
		
	}

}
