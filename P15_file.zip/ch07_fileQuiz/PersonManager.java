package ch07_fileQuiz;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class PersonManager {

	private Scanner scanner = new Scanner(System.in);
	private ArrayList<Person> list;
	private File record;
	
	public PersonManager() throws IOException {
		list = new ArrayList<>();
		File path = new File("D:\\PersonList");
		record = new File(path, "PersonRecord.txt");
		
		if(record.createNewFile()) {
			System.out.println(record.getName() + "파일 생성");
		}
		load();
	}

	public void insert() {
		System.out.println("-추가-");
		System.out.print("이름 입력 >> ");
		String name = scanner.next();
		System.out.print("번호 입력 >> ");
		String phone = scanner.next();
		
		list.add(new Person(name, phone));
		save();
	}
	
	public void delect() {
		System.out.println("-삭제-");
		System.out.print("이름 입력 >> ");
		String dname = scanner.next();
		Person man = findName(dname);
		if(man == null) {
			System.out.println("해당 회원은 없는 사람");
		}
		list.remove(man);
		System.out.println(man + "이(가) 삭제 되었습니다");
		save();
	}
	
	public Person findName(String search) {
		for(Person man : list) {
			if(man.getname().equals(search)) {
				return man;
			}
		}
		return null;
	}
	
	public void view() {
		System.out.println("-목록-");
		for(Person man : list) {
			System.out.println(man);
		}
		System.out.println("회원수 : " + list.size());
		System.out.println();
	}
	
	public void modify(String name) {
		System.out.println("-수정-");
		System.out.print("이름 입력 >> ");
		String dname = scanner.next();
		Person man = findName(dname);
		if(man == null) {
			System.out.println("해당 회원은 없는 사람");
		} else {
		list.remove(man);
		System.out.println("변경할 번호 입력 > ");
		String cnum = scanner.next();
		System.out.println(cnum + "으(로) 수정됨");
		list.add(new Person(dname, cnum));
		save();
		}
	}
	
	public void confirm() {
		System.out.println("-확인-");
		System.out.print("이름 입력 >> ");
		String find = scanner.next();
		if(find == null) {
			System.out.println("해당 회원은 없는 사람");
		} else {
			for(Person man : list) {
				System.out.println(man);
			}
		}
	}

	public void save() {

		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
		ObjectOutputStream oos = null;
		
		try {
			
			fos = new FileOutputStream(record);
			bos = new BufferedOutputStream(fos);
			oos = new ObjectOutputStream(bos);
			
			for(Person man : list) {
				oos.writeObject(man);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(oos != null) oos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println(record.getName() + "저장 완료");
		
	}
	
	public void load() {
		if(record.length() == 0) return;
		
		if(list != null) {
			list.clear();
		}
		
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		ObjectInputStream ois = null;
		
		try {
			
			fis = new FileInputStream(record);
			bis = new BufferedInputStream(fis);
			ois = new ObjectInputStream(bis);
			
			while(true) {
				Person man = (Person)ois.readObject();
				// readObject() 메서드가 읽어드릴 데이터가 없으면 EOFException 예외 발생
				list.add(man);
			}
		} catch(EOFException e) {	
			try {
				if(ois != null) ois.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		} catch (Exception e) {
			
		}
		System.out.println(record.getName() + " 로드 성공");

	}

	
}
