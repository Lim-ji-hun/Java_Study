package ch07_fileQuiz;

import java.io.IOException;
import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) throws IOException {
		
		Scanner scanner = new Scanner(System.in);
		PersonManager manager = new PersonManager();
		
		while(true) {
			
			System.out.println("--- 전화번호 관리 프로그램 ---");
			System.out.println("1.추가 2.삭제 3.목록 4.수정 5.확인 6.저장 7.불러오기\n>> ");
			int select = scanner.nextInt();
			
			switch(select) {
			case 1:
				manager.insert();
				break;
			case 2:
				manager.delect();
				break;
			case 3:
				manager.view();
				break;
			case 4:
				manager.modify(null);
				break;
			case 5:
				manager.confirm();
				break;
			case 6:
				manager.save();
				break;
			case 7:
				manager.load();
				break;
			case 0:
				System.out.println("종료");
				System.exit(0);
			default:
				System.out.println("잘못된 선택");

			}

		}

	}
	
	
	
	
}
