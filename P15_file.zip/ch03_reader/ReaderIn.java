package ch03_reader;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ReaderIn {
	
	public static void main(String[] args) throws IOException {
		
		File path = new File("D:" + File.separator + "P15_file");
		File mf = new File(path, "reader.txt");
		
		if(mf.createNewFile()) {
			System.out.println(mf.getName() + "파일 생성");
		} 
		
		FileInputStream fis = new FileInputStream(mf);
		BufferedInputStream bis = new BufferedInputStream(fis);
		DataInputStream dis = new DataInputStream(bis);
		//주의 읽어드릴때 기록한 순서대로 읽어애됨
		
		int ia = dis.readInt();
		double da = dis.readDouble();
		String sd = dis.readUTF();
		
		System.out.println(ia);
		System.out.println(da);
		System.out.println(sd);
		
		dis.close();
		bis.close();
		fis.close();
		
		
		
		
	}

}
