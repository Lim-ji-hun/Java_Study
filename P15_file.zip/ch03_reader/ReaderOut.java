package ch03_reader;

import java.io.BufferedOutputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReaderOut {
	
	public static void main(String[] args) throws IOException {
		
		File path = new File("D:" + File.separator + "P15_file");
		File mf = new File(path, "reader.txt");
		
		if(mf.createNewFile()) {
			System.out.println(mf.getName() + "파일 생성");
		} 
		
		//데이터 전송 통로 생성
		FileOutputStream fos = new FileOutputStream(mf);
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		DataOutputStream dos = new DataOutputStream(bos);
		
		dos.writeInt(123);
		dos.writeDouble(5.6);
		dos.writeUTF("한글어쩌고 wjWjrh");
		
		dos.close();
		bos.close();
		fos.close();
		
		
		
		
	}

}
