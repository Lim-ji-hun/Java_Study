package ch05_copy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BinaryCopy {
	
	public static void main(String[] args) throws IOException {
		
		File original = new File("D:\\P15_file\\sentence.txt");
		
		File copyPath = new File("D:\\P15_file\\copyPath");
		
		if(copyPath.exists() == false) {
			copyPath.mkdir();
			System.out.println("없으니깐 내가 만듬ㅇㅇ");
			}

		File copy = new File(copyPath, "copy.txt");
				
		if(copy.createNewFile()) {
			System.out.println(copy.getName() + "파일 생성");
			} 
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			
			fis = new FileInputStream(original);
			fos = new FileOutputStream(copy);
			
			int data = 0;
			while((data = fis.read()) != 1) {
				fos.write((byte)data);
			}
			System.out.println(copy.getPath() + "복사 완료");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
				fos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
