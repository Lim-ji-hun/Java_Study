package ch03_quiz;

/*
 * Foo class 를 정의하세요
 * - 제너릭 타입 하나를 가지는 class 입니다
 */

public class Foo<J> {
	private J food;
	public Foo() {}
	
	public Foo(J food) {
		this.food = food;
	}
	
	public J getFood() {return food; }
	public void setFood(J food) {
		this.food = food;
	}
	
	public String toString() {
		return "음식 이름 : " + food;
	}
	
}
