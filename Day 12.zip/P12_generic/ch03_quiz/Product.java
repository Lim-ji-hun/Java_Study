package ch03_quiz;

/*
 * Product class 를 정의하세요
 * - 제품이름, 가격의 관리가 가능합니다
 */

public class Product<K, M> {
	
	private K name;
	private M price;
	
	public Product() {}
	
	public Product(K name, M price) {
		this.name = name;
		this.price = price;
	}

	public K getName() {return name; }
	public void setName(K name) {
		this.name = name;
	}
	
	public M getPrice() {return price; }
	public void setPrice(M price) {
		this.price = price;
	}
	
	public String toString() {
		return "제품 이름 : " + name + " - " + "제품 가격 : " + price;
	}
	
	
	
	
	
	

}
