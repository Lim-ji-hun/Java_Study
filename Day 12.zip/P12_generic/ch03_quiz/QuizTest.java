package ch03_quiz;

/*
 * Foo class 의 Product class 를 적용한 객체를 생성하세요
 */

public class QuizTest {
	public static void main(String[] args) {
		
		Product<Foo, String> proB = 
				new Product<>(new Foo("카레"), "1000원");
		System.out.println(proB);
		
		
	}

}
