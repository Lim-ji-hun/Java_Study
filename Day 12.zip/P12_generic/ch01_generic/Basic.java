package ch01_generic;

public class Basic {
	
	private Object obj;
	
	public Object getObj() {return obj;}
	
	public void setObj(Object obj) {
		this.obj = obj;
	}

}
