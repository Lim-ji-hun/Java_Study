package ch01_generic;

public class Fruits {
	private String name;
	private int ea;
	
	public Fruits(String name, int ea) {
		this.name = name;
		this.ea = ea;
	}
	
	public String toString() {
		return "품명 : " + name + " - 수량 : " + ea;
	}
	
	
}
