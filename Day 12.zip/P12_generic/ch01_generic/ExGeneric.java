package ch01_generic;

/*
 * generic
 * - 모든종류의 데이터타입을 다룰수있도록 일반화된 타입 매개변수로 class를 정의하는 방법
 * - 선업시에 클래스명 뒤에 '<>' 기호를 붙여서 괄호안에 타입 파라메터 이름을 정의
 * 
 * 
 */

public class ExGeneric<T> {
	
	private T data;
	
	public T getData() {return data;}
	
	public void setData(T data) {
		this.data = data;
	}
	

}
