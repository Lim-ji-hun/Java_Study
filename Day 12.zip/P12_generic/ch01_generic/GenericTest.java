package ch01_generic;

public class GenericTest {
	
	public static void main(String[] args) {
		Basic basicA = new Basic();
		basicA.setObj(new String("BasicA"));
		
		String stnA = (String)basicA.getObj();
		System.out.println(stnA);
		
		Basic basicB = new Basic();
		basicB.setObj(new Fruits("충주 사과", 10));
		Fruits fra = (Fruits)basicB.getObj();
		System.out.println(fra);
		
		ExGeneric<String> egA = new ExGeneric<String>();
		egA.setData("test");
		String stnB = egA.getData();
		System.out.println(stnB);
		
		ExGeneric<Fruits> egB = new ExGeneric<>();
		egB.setData(new Fruits("바나나", 5));
		Fruits frb = egB.getData();
		System.out.println(frb);
		
		ExGeneric<Integer> egC = new ExGeneric<>();
		egC.setData(100);
		int ia = egC.getData();
		System.out.println();
		
		ExGeneric<String> egD = new ExGeneric<>();
		egD.setData("123");
		int ib = Integer.parseInt(egD.getData());
		
		
		
		
		
	}
	
}
