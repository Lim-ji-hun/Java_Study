package ch02_generic;

public class Computer {
	
	private String name;
	public Computer(String name) {
		this.name = name;
	}
	
	public String getComputer() {return name;}
	
	public String toString() {
		return "종류 : " + name;
	}
	
	
}
