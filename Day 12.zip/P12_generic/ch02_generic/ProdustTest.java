package ch02_generic;

public class ProdustTest {
	
	public static void main(String[] args) {
		
		Product<String, String> proA = new Product<>();
		proA.setKind("음료");
		proA.getModel("코카콜라");
		System.out.println(proA);
		
		Product<Computer, String> proB = 
				new Product<>(new Computer("노트북"), "grem");
		System.out.println(proB);
		
	}
	
	
}
