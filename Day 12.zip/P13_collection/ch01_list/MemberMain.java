package ch01_list;

public class MemberMain {
	
	public static void main(String[] args) {
		
		MemberManager manager = new MemberManager();
		manager.menu();
		
		
		
	}

}
