
package ch01_list;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MemberManager {
	
	private Scanner scanner = new Scanner(System.in);
	private List<Member> list;
	
	public MemberManager() {
		list = new ArrayList<>();
		list.add(new Member("memberA", 20));
		list.add(new Member("memberB", 30));
		list.add(new Member("memberC", 40));
	}
	
	public int inputInterger(String message) {
		System.out.println(message);
		int value = scanner.nextInt();
		return value;
		
	}
	
	public void menu() {
		while(true) {
			int select = inputInterger("1.추가  2.삭제  3.목록  4.수정  5.확인 > ");
			
			switch(select) {
			case 1://추가
				insert();
				break;
			case 2://삭제
				delete();
				break;
			case 3://목록
				view();				
				break;
			case 4://수정
				modify();
				break;
			case 5://확인
				confirm();
				break;
			case 0://종료
				end();
			default:
				System.out.println("선택 오류");

			}
		}
		
		
	}
	
	public void insert() {//1 추가
		System.out.println("--- 회원 추가 ---");
		System.out.print("이름 입력 >> ");
		String name = scanner.next();
		System.out.print("나이 입력 >> ");
		int age = scanner.nextInt();
		list.add(new Member(name, age));
	}
	
	public void delete() {//2 삭제
		
		System.out.println("--- 회원 삭제 ---");
		System.out.print("삭제 이름 입력 >> ");
		String dname = scanner.next();
		Member man = findName(dname); //삭제 이름을 가진 회원 찾기
		if(man == null) {
			System.out.println("해당 회원은 없는 사람");
		}
		list.remove(man);
		System.out.println(dname + "삭제 함");

	}

	//회원 이름 검색
	public Member findName(String search) {
		
		for(Member man : list) {
			if(man.getName().equals(search)) {
				return man;
			}
		}
		return null;
	}
	
	
	public void view() {//3 목록
		System.out.println("--- 회원 목록 ---");
		for(Member man : list) {
			System.out.println(man);
		}
		System.out.print("회원수 : " + list.size());
		System.out.println();
	}
	
	public void modify() {//수정
		System.out.println("--- 회원 수정 ---");
		System.out.print("찾는 이름 입력 >> ");
		String change = scanner.next();
		Member man = findName(change); //수정 이름을 가진 회원 찾기
		if(man == null) {
			System.out.println("해당 회원은 없는 사람");
		}
		int nameNum = list.indexOf(man);
		System.out.print("수정 이름 입력 >> ");
		String changeA = scanner.next();
		System.out.print("수정 나이 입력 >> ");
		int changeB = scanner.nextInt();
		list.set(nameNum, new Member(changeA, changeB));
		
	}
	
	public void confirm() {//확인
		System.out.println("--- 회원 찾기 ---");
		System.out.print("찾는 이름 입력 >> ");
		String find = scanner.next();
		Member man = findName(find);
		if(man == null) {
			System.out.println("해당 회원은 없는 사람");
		}
		int Num = list.indexOf(man);
		System.out.println("회원 정보 : " + list.get(Num));
	}
	
	
	public void end() {//0 종료
		System.out.println("-program end-");
		System.exit(0); // 현 위치에서 강제로 종료
	}
	
}
