package ch02_set;

public class Member1 {
	
	private String name;
	private int age;
	
	public Member1(String name, int age) {
		this.age = age;
		this.name = name;
	}
	
	public String getName() {return name;}
	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {return age;}
	public void setName(int age) {
		this.age = age;
	}
	
	public int hashCode() {
		return name.hashCode() + age;
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof Member1) {
			Member1 tmp = (Member1)obj;
			if(!this.name.equals(tmp.name)) 
				return false;
			
			if(this.age != tmp.age) 
				return false;

			return true;
		}
		return false;
	}
	
	public String toString() {
		return name + " - " + age;
	}
	
}
