package ch02_set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ExHashSet {
	
	public static void main(String[] args) {
		
		//HashSet<Member> hs = new HashSet<>();
		Set<Member1> hs = new HashSet<>();
		
		Member1 memA = new Member1("유재석", 50);
		Member1 memB = new Member1("유재석", 50);
		
		hs.add(memA);
		hs.add(memB);
		hs.add(new Member1("김종국", 48));
		hs.add(new Member1("송지효", 46));
		System.out.println(hs);
		
		System.out.println("데이터 수 : " + hs.size());
		System.out.println();
		
		for(Member1 man : hs) {
			System.out.println(man);
		}
		System.out.println();
		
		Iterator<Member1> it = hs.iterator();	
		String dname = "유재석";
		while(it.hasNext()) {
			Member1 man = it.next();
			if(man.getName().equals(dname)) {
				System.out.println("찾음");
				it.remove();
			}
		}
		System.out.println(hs);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
