package ch03_quiz;

/*
 * Person class 를 정의하세요
 * - 이름, 전화번호의 관리가 가능합니다
 */

public class Person {

   private String name;
   private String phone;
   
   
   public Person(String name, String phone) {
	   this.name = name;
	   this.phone = phone;
   }
   
   public String getname() {return name;}
   public void setname(String name) {
	   this.name = name;
   }
   
   public String getphone() {return phone;}
   public void setphone(String phone) {
	   this.phone = phone;
   }
   
//   public int hashCode() {
//	   return name.hashCode() + phone.hashCode();
//   }
   
   public boolean equals(Object obj) {
	   if(obj instanceof Person) {
		   Person tmp = (Person)obj;
		   if(!this.name.equals(tmp.name)) 
			   return false;
		   if(!this.phone.equals(tmp.phone)) 
			   return false;
		   return true;
			}
		return false;
		}
   
   public String toString() {
	   return name + " - " + phone;
   }
   
  
   
}