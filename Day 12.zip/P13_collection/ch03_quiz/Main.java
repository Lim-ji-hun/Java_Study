package ch03_quiz;

public class Main {
	
	public static void main(String[] args) {
		PersonManager personManager = new PersonManager();
		personManager.menu();
	}

}
