package ch03_quiz;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/*
 * Person class 객체를 Set collection 으로 관리하는 PersonManager class 를 구현하세요
 * - 구현 방식은 ch01_list 팩키지의 MemberManager class 와 동일합니다
 */

public class PersonManager {
	
	private Scanner scanner = new Scanner(System.in);
	private Set<Person> set;
	
	public PersonManager() {
		set = new HashSet<>();
	}
	
	// 메뉴
	public void menu() {
		
		while(true) {
			System.out.print("1.추가  2.삭제  3.목록 >> ");
			int select = scanner.nextInt();
			
			switch(select) {
			case 1: // 추가
				insert();
				break;
			case 2: // 삭제
				delete();
				break;
			case 3: // 목록
				list(); 
				break;
			case 0: // 종료
				end();
			default:
				System.out.println("선택 오류~");
			}
			System.out.println();
		}
		
		
		
	} // menu()
	
	public void insert() {
		System.out.println("-추가-");
		
		System.out.print("이름 입력 >> ");
		String name = scanner.next();
		
		System.out.print("번호 입력 >> ");
		String phone = scanner.next();
		
		set.add(new Person(name, phone));
	}
	
	public void delete() {
		System.out.println("-삭제-");
		
		System.out.print("이름 입력 >> ");
		String dname = scanner.next();
		Person man = findName(dname);
		if(man == null) {
			System.out.println("해당 회원은 없는 사람");
		}
		set.remove(man);
		System.out.println(man + "이(가) 삭제 되었습니다");
	}
	
	public Person findName(String search) {
		for(Person man : set) {
			if(man.getname().equals(search)) {
				return man;
			}
		}
		return null;
	}
	
	
	public void list() {
		System.out.println("-목록-");
		for(Person man : set) {
			System.out.println(man);
		}
		System.out.print("회원수 : " + set.size());
		System.out.println();
	}
	
	public void end() {
		System.out.println("-program end-");
		System.exit(0);
	}
	
	
	
	
	
	
}





















