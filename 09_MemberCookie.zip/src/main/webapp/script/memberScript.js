



/* script/memberScript.js */

// 회원 정보 입력 확인
function checkWrite(){
	if(document.writeForm.name.value==""){
		alert("이름을 입력하세요~");
		document.writeForm.name.focus();
	} 
	else if(document.writeForm.id.value==""){
		alert("아이디를 입력하세요~");
		document.writeForm.id.focus();
	} 
	else if(document.writeForm.pwd.value==""){
		alert("비밀번호를 입력하세요~");
		document.writeForm.pwd.focus();
	} 
	else if(document.writeForm.pwd.value != document.writeForm.repwd.value){
		alert("비밀번호가 틀려요~");
		document.writeForm.repwd.focus();
	} 
	else if(document.writeForm.email.value==""){
		alert("이메일을 입력하세요~");
		document.writeForm.email.focus();
	} 
	else if(document.writeForm.tel_1.value==""){
		alert("전화번호를 입력하세요~");
		document.writeForm.tel_1.focus();
	} 
	else if(document.writeForm.tel_2.value==""){
		alert("전화번호를 입력하세요~");
		document.writeForm.tel_2.focus();
	} 
	else if(document.writeForm.tel_3.value==""){
		alert("전화번호를 입력하세요~");
		document.writeForm.tel_3.focus();
	} 
	else if(document.writeForm.addr.value==""){
		alert("주소를 입력하세요~");
		document.writeForm.addr.focus();
	} 
	else {
		document.writeForm.submit();
	}
	
}


// 아이디 중복 체크
function checkId(){
	let userid = document.writeForm.id.value;
	
	if(userid == ""){
		alert("아이디를 입력하세요~");
		document.writeForm.id.focus();
	}
	else {
		window.open("./checkId.jsp?id=" + userid, "", "left=200, top=200, width=500, height=300");
	}
}


// 로그인
function login(){
	if(document.loginForm.id.value==""){
		alert("아이디를 입력하세요~");
		document.loginForm.id.focus();
	}
	else if(document.loginForm.pwd.value==""){
		alert("패스워드를 입력하세요~");
		document.loginForm.pwd.focus();
	}
	else {
		document.loginForm.submit();
	}
	
}
























