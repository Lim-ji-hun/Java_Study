
// 로그인
function login(){
	if(document.loginForm.id.value==""){
		alert("아이디를 입력하세요~");
		document.loginForm.id.focus();
	}
	else if(document.loginForm.pwd.value==""){
		alert("패스워드를 입력하세요~");
		document.loginForm.pwd.focus();
	}
	else {
		document.loginForm.submit();
	}
	
}
























