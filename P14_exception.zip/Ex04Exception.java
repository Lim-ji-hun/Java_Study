
public class Ex04Exception {
	
	public static void main(String[] args) {
		
		try {
			
			int res = Calc.div(10, 3);
			System.out.println("res : " + res);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
