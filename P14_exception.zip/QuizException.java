import java.util.Scanner;

public class QuizException {
	
	// 사용자에게 ID 를 입력받습니다
    // 정상이면 사용 가능하고, 문제가 있으면 다시 실행해서 재입력을 받습니다
    // - ID 는 2 ~ 10 글자 사이만 가능합니다
    //   ID 에 'admin' 단어가 포함되어 있으면 안됩니다
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("사용할 ID 를 입력 >> ");
		String id = scanner.next();
		
		try {
			
			if(id.length() < 2 || id.length() >10) {
				throw new Exception("ID 는 2 ~ 10 글자 사이만 가능합니다");
			} else if(id.contains("admin")) {
				throw new Exception("ID 에 'admin' 단어가 포함되어 있으면 안됩니다");
			} else {
				System.out.println(id);
			}
			
		
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
