import java.util.Scanner;

/*
 * 예외 (exception)
 * - 잘못된 코드 또는 사용자의 장못된 조작으로 인래 발생하는 프로그램 오류
 * 
 * 예외처리
 * 프로그램에서 문제가 발생했을때 문제 내용을 처리하는것
 * Ex) try() {
 *            문제가 발생할 수도 있는 지역
 * } catch( 예외 타입 ) {
 *      예외처리 지역
 *      > catch의 예외 타입으로 기본자료형을 사용 불가          
 * } finally {
 *      예외 처리와 상관 없이 무조건 실행됨 (사용 O, X)
 * }
 * 
 */
public class Ex01Exception {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int candy = 0;
		int person = 0;
		
		try {
			System.out.println("사탕 갯수입력 > ");
			candy = scanner.nextInt();
			System.out.println("사람 갯수입력 > ");
			person = scanner.nextInt();
			
			int div = candy/person;
			int mod = candy%person;
			
			System.out.println("한 사람 사탕수 : " + div);
			System.out.println("남은 사탕수 : " + mod);
		} catch (Exception e) {
			//System.out.println("0으론 나눌수 없음");
			//e.printStackTrace(); //상새한 내용
			//System.out.println(e.toString()); //조금 덜 상세한 내용
			System.out.println(e.getMessage()); //간단한 내용
			System.err.println(e.getMessage()); //빨간색갈
		} finally {
			System.out.println("계산 종료");
		}
		
		
	}

}
