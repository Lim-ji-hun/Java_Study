
public class Ex02Exception {
	
	public static void main(String[] args) {
		
		String[] sa = new String[] {"1", "2", "삼"};
		int[] ia = new int[sa.length];
		
		try {
			
			for(int i=0 ; i<sa.length ; i++) {
			//for(int i=0 ; i<4 ; i++) {
				ia[i] = Integer.parseInt(sa[i]);
				System.out.println(ia[i] + " ");
			}
			System.out.println();
		}
		
		catch (NumberFormatException e) {
			System.out.println(e.toString());
			System.out.println("NumberFormatException e");
		}
		
		catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			System.out.println("ArrayIndexOutOfBoundsException e");
		}	

		catch (Exception e) { //Exception이 상위이기 떄문에 catch를 여러개 쓰면 순서를 잘 맞춰야함
			e.printStackTrace();
			System.out.println("Exception e");
		} 
		
		
	}

}
