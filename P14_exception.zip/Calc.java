
public class Calc {
	
	public static int div(int a, int b) throws Exception {
		return a/b;
	}
	
	
	
}
