import java.util.Scanner;

public class Ex03Exception {
	
	public static void main(String[] args) {
		
Scanner scanner = new Scanner(System.in);
		
		int candy = 0;
		int person = 0;
		
		try {
			System.out.println("사탕 갯수입력 > ");
			candy = scanner.nextInt();
			System.out.println("사람 갯수입력 > ");
			person = scanner.nextInt();
			
			if(person < 1) 
				throw new Exception("1 미만의 사람 수");
			
			int div = candy/person;
			int mod = candy%person;
			
			System.out.println("한 사람 사탕수 : " + div);
			System.out.println("남은 사탕수 : " + mod);
		} 
		
		catch (Exception e) {
			e.printStackTrace();
			//System.err.println(e.getMessage()); //빨간색갈
		} 
		
		finally {
			System.out.println("계산 종료");
		}
		
	}

}
