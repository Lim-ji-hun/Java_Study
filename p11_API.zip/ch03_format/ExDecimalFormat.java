package ch03_format;

import java.text.DecimalFormat;

/*
 * DecimalFotmat
 * - 숫자를 원하는 형태의 문자열로 변환할 때 사용
 *   0 : 빈자리 0으로 채움
 *   # : 빈자리 0으로 채우지 않음
 */
public class ExDecimalFormat {
	
	public static void main(String[] args) {
		
		double data = 12345.600;
		System.out.println("data : " + data);
		System.out.println();
		
		DecimalFormat df = null;
		
		df = new DecimalFormat("0");
		String sa = df.format(data);
		System.out.println(sa);
		
		df = new DecimalFormat("0.00");
		String sb = df.format(data);
		System.out.println(sb);
		
		df = new DecimalFormat("000,000.000");
		String sc = df.format(data);
		System.out.println(sc);
		
		df = new DecimalFormat("###,###.###");
		String sd = df.format(data);
		System.out.println(sd);
		
		
	}
	
	
}
