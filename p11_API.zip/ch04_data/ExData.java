package ch04_data;

import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * Date
 * - 날짜를 표현할때 사용
 * 
 * SimpleDateFormat
 * - 날짜를 원하는 형태의 문자열로 변환하는 클래스 
 *  y = 년도
 *  M = 월
 *  d = 일
 *  D = 1 ~ 365일
 *  E = 요일
 *  a = 오전/오후
 *  H = 0~24시
 *  h = 0~12시
 *  m = 분
 *  s = 초
 * 
 * 
 */


public class ExData {
	
	public static void main(String[] args) {
		
		Date date = new Date();
		System.out.println(date);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월  dd일 hh시 mm분 ss초");
		
		String currentTime = sdf.format(date);
		System.out.println(currentTime);
		
		
	}

}
