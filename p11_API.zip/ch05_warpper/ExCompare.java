package ch05_warpper;

/*
 * Wrapper class 데이터 비교
 * - Wrapper class 로 포장된 객체의 데이터 비교시네응 '==', '!=' 연신지를 사용할수없음
 *   포장된 객체의 데이터 비교시에는 unboxing 해서 확인하거나 equals()를 사용할수있다
 * - 아래의 5가지 현태로는 바로 비교 가능
 *   > boolean, char, byte, short, int(-128~127)
 *   
 * 
 */

public class ExCompare {
	public static void main(String[] args) {
		
		Integer testA = 1000;
		Integer testB = 1000;
		Integer testC = 127;
		Integer testD = 127;
		
		System.out.println(testA == testB);
		System.out.println(testC == testD);//int범위 값내여서 같다고 나옴
		System.out.println(testA.equals(testB));
		System.out.println(testA.intValue() == testB.intValue());
		
		
	}

}
