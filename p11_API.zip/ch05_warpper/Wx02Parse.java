package ch05_warpper;

/*
 * 파싱 (parsing)
 * - 문자열을 분석해서 해당 형태의 기본자료형으로 변환 함
 *   > parse + 기본자료형()
 *   
 */

class Data {
	private String value;
	
	public Data(String value) {
		this.value = value;
	}
	
	public String getValue() {return value;}
}

public class Wx02Parse {
	
	public static void main(String[] args) {
		
		String stnA = "100";
		
		//int ia = stnA; => error
		int ai = Integer.parseInt(stnA);
		
		String stnB = "2.4";
		double da = Double.parseDouble(stnB);
		
		System.out.println();

		Data dataA = new Data("123");
		String sa = dataA.getValue();
		int a = Integer.parseInt(sa);
		
		Data dataB = new Data("3.4");
		double b = Double.parseDouble(dataB.getValue());
		
		
		
	}

	
	
	
	
	
	
	
	
	
	
	
}
