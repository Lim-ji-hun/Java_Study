package ch05_warpper;

/*
 * Wrapper class
 * - 기본자료형을 포장해서 객체화시키는 클래스
 * - 기본타입       Wrapper
 *   byte        Byte
 *   short       Short
 *   int         Integer
 *   long        Long
 *   float       Float
 *   double      Double
 *   char        Character
 *   
 */

public class Ex01Wrapper {
	public static void main(String[] args) {
		
		//boxing
		// - 기본타입의 값을 포장해서 객체화하는 과정
		// - Wrapper class 의 인자값으로 기본타입의 값 또는 문자열을 사용
		Integer wia = new Integer(1000);
		Integer wib = new Integer("2000");
		Double wda = new Double(2.3);
		//버전에 따라 바뀌는 것들이 있음 이건 8까지만 되던거임 11부터는 auto로 넘어감
		
		//auto boxing
		Integer wic = 3000;
		
		//unboxing
		// - 포장된 객체를 기본타입으로 변환하는 과정
		// - 기본타빙 + Value() 메서드로 unboxing 함
		int ia = wia.intValue();
		double da = wda.doubleValue();
		
		// auto unboxing
		int ib = wib;
		int sum = wic + 2000;
		
		
	}

}
