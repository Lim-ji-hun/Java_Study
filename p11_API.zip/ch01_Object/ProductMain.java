package ch01_Object;

public class ProductMain {
	
	public static void main(String[] args) {
		
		Product proA = new Product("001");
		Product proB = new Product("002");
		Product proC = new Product("001");
		
		System.out.println(proA.equals(proB));
		System.out.println(proA.equals(proC));
		System.out.println();
		
		System.out.println(proA);
		System.out.println(proB);
		System.out.println(proC);
	}

}
