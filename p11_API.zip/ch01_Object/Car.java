package ch01_Object;

/*
 * Car class 를 정의하고, CarMain class 에서 테스트 하세요
 * - 제조회사, 모델명의 관리가 가능합니다
 * - 제조회사, 모델명이 같으면 동일한 차량으로 판단해야 합니다
 * - 변수명을 사용해서 차량 정보를 확인할 수 있습니다
 */

public class Car {
	
	private String company;
	private String model;
	
	public Car(String company, String model) {
		this.model = model;
		this.company = company;
	}
	
	public void CarInfo() {
		System.out.println("--차량 정보--");
		System.out.println("제조 회사 : " + company);
		System.out.println("모델명 : " + model);
		System.out.println();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof Car) {
			Car tmp = (Car)obj;
			if(this.company.equals(tmp.company) && this.model.equals(tmp.model)) {
				return true;
			}
		}
		return false;
	}
	
	public String toString() {
		return "차량 정보 - " + company + ", " + "모델명 - " + model;
	}

}
