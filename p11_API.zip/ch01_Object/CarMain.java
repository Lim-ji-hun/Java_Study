package ch01_Object;

public class CarMain {
	
	public static void main(String[] args) {
		
		Car car1 = new Car("현대", "제네시스");
		car1.CarInfo();
		
		Car car2 = new Car("현대", "제네시스");
		car2.CarInfo();
		
		System.out.print("두 차량이 같은 차량인가 >> ");
		System.out.println(car1.equals(car2));
		
		System.out.println(car1);
		System.out.println(car2);
		
		
	}

}
