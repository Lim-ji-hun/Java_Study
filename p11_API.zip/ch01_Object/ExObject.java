package ch01_Object;

import java.lang.*;

/*
 * 자바의 모든 클래스는 Object class를 무조건 사용함
 * 
 */

//public class ExObject extends object {}
public class ExObject {//정의 하지않아도 extends object가 포함되어있음
	public static void main(String[] args) {

		Object objA = new Object();
		Object objB = new Object();
		
		//getClass() : class type 반환
		System.out.println("objA.getClass() : " + objA.getClass());
		
		System.out.println();
		
		//hashCode() : 객체 고유번호
		System.out.println("objA.hashCode() : " + objA.hashCode());
		System.out.println("objB.hashCode() : " + objB.hashCode());

		System.out.println();
		
		//toString() : getClass(), hashCode() 조합
		System.out.println("objA.toString() : " + objA.toString());
		System.out.println("objA : " + objA);

		System.out.println();
		
		//equals() : 동일한 객체인지 확인
		System.out.println("objA.equals(objB) : " + objA.equals(objB));
		
		
		
	}

}
