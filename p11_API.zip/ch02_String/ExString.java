package ch02_String;

public class ExString {
	public static void main(String[] args) {
		
		String stnA = "JAVA";
		String stnB = new String("JAVA");
		String stnC = "JAVA";
		
		System.out.println(stnA);
		System.out.println(stnB);
		System.out.println(stnC);
		System.out.println();
		
		System.out.println(stnA.hashCode());
		System.out.println(stnB.hashCode());
		System.out.println(stnC.hashCode());
		System.out.println();
		
		System.out.println(stnA.equals(stnB));
		System.out.println(stnA.equals(stnC));
		System.out.println();
		
		String title = "자바 progrem";
		System.out.println("title : " + title);
		System.out.println("title 문자수 : " + title.length());
		
		//특정 문자열이 처음으로 나타나는 위치
		int title_pos = title.indexOf("p");
		System.out.println("p 위치 : " + title_pos);
		
		//특정 문자열이 마지막으로 나타나는 위치
		int title_lastPos = title.lastIndexOf("r");
		System.out.println("r 마지막 위치 : " + title_lastPos);
		
		//특정 문자열 변경
		String new_title = title.replace("pro", "Pro");
		System.out.println("new_title : " + new_title);
		
		System.out.println();
		
		String phone = "010-1234-4321";
		System.out.println("phone : " + phone);
		
		// 문자열 자르기
		String pa = phone.substring(4, 8);//시작 index ~ 마지막 index - 1까지
		String pb = phone.substring(9);
		System.out.println("앞 4자리 : " + pa);
		System.out.println("뒤 4자리 : " + pb);
		
		System.out.println();

		String email = "asd@gmail.com";
		System.out.println("E-mail : " + email);
		
		//@의 위치 찾기
		int at = email.indexOf("@");
		
		//아이디 
		String id = email.substring(0, at);
		
		//도메인
		String domain = email.substring(at + 1);
		
		System.out.println("ID : " + id);
		System.out.println("domain : "+ domain);
		
		
		
		
	}

}
