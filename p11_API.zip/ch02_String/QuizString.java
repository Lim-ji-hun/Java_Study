package ch02_String;



public class QuizString {
	public static void main(String[] args) {
		
		// 주민번호를 사용해서 문제를 해결하세요
	    // - 주민번호에서 생년월일을 추출하세요
	    // - 뒤에 7자리 중 첫번째 자리를 사용해서 남성, 여성을 확인하세요
	    //   1 - 1900 년대 남자        2 - 1900 년대 여자
	    //   3 - 2000 년대 남자        4 - 2000 년대 여자
	    String passport = "010101-4123456";
	    
	    String year = passport.substring(0, 2);
	    String month = passport.substring(2, 4);
	    String day = passport.substring(4, 6);
	    
	    System.out.println("년도 : " + year);
	    System.out.println("월 : " + month);
	    System.out.println("일 : " + day);
	    
	    System.out.println();
	    
	    String find = passport.substring(7, 8);
	    if(find.equals("1")) {
	    	 System.out.println("1900 년대 남자");
	    } else if(find.equals("2")) {
	    	System.out.println("1900 년대 여자");
	    } else if(find.equals("3")) {
	    	System.out.println("2000 년대 남자");
	    } else if(find.equals("4")) {
	    	System.out.println("2000 년대 여자");
	    }
	    
	    
	    // 아래의 파일 경로에서 데이터를 추출하세요
	    // - 파일 경로 : "D:/photo/2024/travel/food.jpg"
	    //   파일 이름 : food
	    //   확장자    : jpg
	    
	    String file = "D:/photo/2024/travel/food.jpg";
	    
	    int file_lastPos = file.lastIndexOf("/");
	    int dat_lastPos = file.lastIndexOf(".");
	    
	    
	    String filename = file.substring(file_lastPos+1, dat_lastPos);
	    
	    System.out.println("파일 이름 : " + filename);
	    
	    String plus = file.substring(dat_lastPos+1);
		
	    System.out.println("확장자 : " + plus);
	    

	}

}
