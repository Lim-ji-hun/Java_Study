package ch04_map;

import java.util.Scanner;

public class MemberMain {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		MemberManager manager = new MemberManager();
		
		while(true) {
			System.out.println("--- 회원 관리 ---");
			System.out.println("1.가입 2.삭제 3.목록 >> ");
			int select = scanner.nextInt();
			
			switch(select) {
			case 1:
				System.out.println("ID 입력 > ");
				String id = scanner.next();
				if(manager.checkId(id)) {
					System.out.println("사용중인 id 입니다");
				} else {
					System.out.println("이름 입력 >> ");
					String name = scanner.next();
					manager.insert(id, name);
				}
				break;
			case 2:
				System.out.println("삭제 ID 입력 > ");
			    String did = scanner.next();
			    manager.delete(did);
				break;
			case 3:
				manager.list();
				
				break;	
			case 0:
				System.out.println("끝");
				System.exit(0);;	
			default:
				System.out.println("선택 오류");
				
			}
			System.out.println();
			
			
		}
		
	}

}
