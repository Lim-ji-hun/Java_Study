package ch04_map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MemberManager {
	
	//         key:id, value:Member
	public Map<String, Member> map;

	public MemberManager() {
		map = new HashMap<>();
	}
	
	//id확인
	public boolean checkId(String id) {
		if(map.containsKey(id)) {
			return true;
		}
		return false;
	}
	
	//회원 추가
	public void insert(String id, String name) {
		map.put(id, new Member(id, name));
	}
	
	public void list() {
		Set<String> sey = map.keySet();
		Iterator<String> it = sey.iterator();
		while(it.hasNext()) {
			String key = it.next();
			Member value = map.get(key);
			System.out.println(value);
		}
	}
	
	public void delete(String id) {
		if(map.containsKey(id)) {
			map.remove(id);
			System.out.println(id + "삭제");
		} else {
			System.out.println("없는 ID 입니다.");
		}
	}

}
