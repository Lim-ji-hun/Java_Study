package ch05_mapQuiz;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class PersonManager {

   private Scanner scanner = new Scanner(System.in);
   private Map<String, Person> map;  // key - 이름, value - Person
   
   public PersonManager() {
      map = new HashMap<>();
   }
   
   public boolean check(String name) {
	   if(map.containsKey(name)){
		   return true;
	   }
	   return false;
   }
   
   public void insert(String name, String phone) {
	   map.put(name, new Person(name, phone));
   }
   
   public void delete(String name) {
	   if(map.containsKey(name)) {
		   map.remove(name);
		   System.out.println(name + " 삭제");
	   } else {
		   System.out.println("없는 이름임");
	   }
   }
   
   public void list() {
	   Set<String> sey = map.keySet();
	   Iterator<String> it = sey.iterator();
	   while(it.hasNext()) {
		   String key = it.next();
		   Person value = map.get(key);
		   System.out.println(value);
	   }
   }
   
   public void modify(String name) {
	   if(map.containsKey(name)) {
		   
	   } else {
		   System.out.println("없는 이름임");
	   }
   }
   
   
}