package ch05_mapQuiz;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		PersonManager manager = new PersonManager();
		
		boolean run = true;  // 실행 : true, 종료 : false
		while(run) {
			System.out.println("--- 전화번호  관리 ---");
			System.out.print("1.추가  2.삭제  3.목록  4.수정\n>> ");
			int select = scanner.nextInt();
			
			switch(select) {
			case 1: // 추가 : 이름으로 관리
				System.out.println("이름 입력 > ");
				String name = scanner.next();
				if(manager.check(name)) {
					System.out.println("사용중인 이름");
				} else {
					System.out.println("번호 입력 > ");
					String phone = scanner.next();
					manager.insert(name, phone);
				}
				break;
			case 2: // 삭제 : 이름으로 삭제
				System.out.println("삭제할 이름 입력 > ");
				String dname = scanner.next();
				manager.delete(dname); 
				break;
			case 3: // 목록
				manager.list(); 
				break;
			case 4: // 수정 : 이름으로 전화번호 수정
				System.out.println("찾는 이름 입력 > ");
				String fname = scanner.next();
				manager.modify(fname);
				System.out.println("변경할 번호 입력 > ");
				String cnum = scanner.next();
				System.out.println(cnum + "으(로) 수정됨");
				manager.insert(fname, cnum);
				
				break;
			case 0: // 종료
				run = false;
				break;
			default:
				System.out.println("선택 오류~");
			}
			System.out.println();
		}
		System.out.println("- Progeam end -");
		
	}
	
}





