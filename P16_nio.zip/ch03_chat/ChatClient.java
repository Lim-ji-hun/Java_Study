package ch03_chat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		//클라이언트
		Socket socket = null;
		BufferedWriter out = null;
		BufferedReader in = null;
		
		try {
			socket = new Socket("localhost", 10000);
			System.out.println("서버 연결");
			
			//출력 스트림
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			String clientTransmit = null;
			while(true) {		

				System.out.print("클라이언트 송신 > ");
				clientTransmit = scanner.nextLine();
				if(clientTransmit.equals("bye")) {
					out.write(clientTransmit + "\n");
					out.flush();
					break;
				}
				
				out.write(clientTransmit + "\n");
				out.flush(); //스트림 안의 데이터를 모두 전송
				System.out.println();
				
				String clientReceive = in.readLine();
				System.out.println("클라이언트 수신 : " + clientReceive);
				
			}
			
		} catch (Exception e) {
			System.out.println("에러");
		} finally {
			try {
				
				if(in != null) in.close();
				if(out != null) out.close();
				if(socket != null) socket.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
	}


	

}
