package ch03_chat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class ChatServer {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		ServerSocket listener = null;
		Socket socket = null;
		BufferedReader in = null;
		BufferedWriter out = null;
		
		try {
			
			listener = new ServerSocket(10000); //서버 소켓 생성
			System.out.println("- Server 준비 -");
			
			socket = listener.accept(); // 클라이언트로부터 연결 요청 대기
			
			//클라이언트로부터의 입력 스트림
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			//클라이언트로부터의 출력 스트림
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			String clientmessage = null;
			while(true) {
				
				clientmessage = in.readLine(); //클라이언트가 전송한 데이터 가져오기
				if(clientmessage.equals("bye")) {
					System.out.println("연결 종료");
					break;
				}
				System.out.println("server 수신 : " + clientmessage);
				System.out.println();
				
				System.out.print("Server 입력 > ");
				String servermessage = scanner.nextLine();
				out.write(servermessage + "\n");
				out.flush();
			}
			
			
		} catch (Exception e) {
			System.out.println("에러");
		} finally {
			try {
				
				if(out != null) out.close();
				if(in != null) in.close();
				if(socket != null) socket.close();
				if(listener != null) listener.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
		


}
