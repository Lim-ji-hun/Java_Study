package ch02_echo;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;

public class EchoCliant {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		//클라이언트
		Socket socket = null;
		BufferedWriter out = null;
		
		try {
			socket = new Socket("127.0.0.1", 10000);
			System.out.println("서버 연결");
			
			//출력 스트림
			out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			System.out.print("전송 데이터 입력 > ");
			String message = scanner.nextLine();
			
			out.write(message + "\n");
			out.flush(); //스트림 안의 데이터를 모두 전송
			
			
			
		} catch (Exception e) {
			System.out.println("에러");
		} finally {
			try {
				
				if(out != null) out.close();
				if(socket != null) socket.close();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
	}

	
}
