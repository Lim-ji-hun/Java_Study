package ch02_echo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class EchoServer {
	
	public static void main(String[] args) {
		
		ServerSocket listener = null;
		Socket socket = null;
		BufferedReader in = null;
		
		try {
			
			listener = new ServerSocket(10000); //서버 소켓 생성
			System.out.println("- Server 준비 -");
			
			socket = listener.accept(); // 클라이언트로부터 연결 요청 대기
			
			//클라이언트로부터의 입력 스트림
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			String clientMessage = in.readLine(); //클라이언트로부터 한행의 텍스트 읽기
			System.out.println("클라이언트 : " + clientMessage);
			
		} catch (Exception e) {
			System.out.println("에러");
		} finally {
			try {
				
				if(in != null) in.close();
				if(socket != null) socket.close();
				if(listener != null) listener.close();
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

}
