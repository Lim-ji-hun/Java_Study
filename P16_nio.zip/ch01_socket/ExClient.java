package ch01_socket;

import java.net.Socket;

public class ExClient {
	
	public static void main(String[] args) {
		
		Socket socket = null;
		
		try {
			
			socket = new Socket("localhost", 10000);
			// localhost( 127.0.0.1 )
			// - 컴퓨터 네트워크에서 사용되는 루프백 호스트명으로 자신의 컴퓨터를 의미
			// cmd에서 ipconfig을 검색하면 ip주소 확인 가능
			
			
		} catch (Exception e) {
			System.out.println("클라이언트 error");
		} finally {
			try {
				if(socket != null) socket.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

}
