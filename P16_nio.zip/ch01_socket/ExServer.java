package ch01_socket;

import java.net.ServerSocket;
import java.net.Socket;

/*
 * #서버, 클라이언트
 * - 서버     : 클라이언트에게 네트워크를 통해서 서비스를 제공하는 시스템
 * - 클라이언트 : 서버와 대응되는 개념으로 서비스를 사용하는 사용자
 * 
 * #Socket
 * - 서버와 클라이언트 간에 통신을 할 수 있도록 해주는 연결 통로
 * - 소켓은 특정 IP 포트 번호와 결합됩니다
 * - 클라이언트는 Socket을 생성하고, 서버는 serverSocket을 생성한 후에 socket을 생성함
 * 
 * #port
 * - 0 ~ 65535번 까지 사용함
 *   > 0 ~ 1023     : well_known port (이미 지정된 포트 사용하면 안됨)
 *     1024 ~ 49151 : 서버 소켓으로 사용함
 *     49152 ~ 65535: 동적 포트
 *     
 * # port확인
 * - netstat -ano
 * 
 * # port 죽이기
 * - taskkill /f /pid pid번호
 * 
 * 
 * 
 */


public class ExServer {
	
	public static void main(String[] args) {
		
		//서버
		ServerSocket listener = null;
		Socket socket = null;
		
		try {
			
			listener = new ServerSocket(10000); //서버 소켓 생성
			System.out.println("- Server 준비 -");
			
			socket = listener.accept(); // 클라이언트로부터 연결 요청 대기
			System.out.println("접속 정보"
					+ " : " + socket.toString());
			
		} catch (Exception e) {
			System.out.println("에러");
		} finally {
			try {
				if(socket != null) socket.close();
				if(listener != null) listener.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		
		
		
		
		
		
	}
	
}
