package imageBoard.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import board.dto.BoardDTO;
import imageBoard.DTO.ImageBoardDTO;



public class ImageBoardDAO {
	
	private Connection con = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private DataSource ds;
	
	public ImageBoardDAO() {
		try {
			Context context = new InitialContext();
			ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void streamClose(ResultSet rs, PreparedStatement pstmt, Connection con) {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}//streamClose() end
	
	
	
	public int imageboardWrite(ImageBoardDTO imageBoardDTO) {
		
		int su = 0;
		
		try {
			
			String sql = "INSERT INTO imageboard values (seq_imageboard.nextval, ?, ?, ?, ?, ?, ?, sysdate)";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, imageBoardDTO.getImageId());
			pstmt.setString(2, imageBoardDTO.getImageName());
			pstmt.setInt(3, imageBoardDTO.getImagePrice());
			pstmt.setInt(4, imageBoardDTO.getImageQty());
			pstmt.setString(5, imageBoardDTO.getImageContent());
			pstmt.setString(6, imageBoardDTO.getImageFile());
			su = pstmt.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return su;
	}
	
	public ArrayList<ImageBoardDTO> imageboardList(int start, int last){
		
		ArrayList<ImageBoardDTO> list = new ArrayList<>();
		ImageBoardDTO imageboardDTO = null;
		
		try {
			
			String sql =  "select * from "
					      + "(select rownum rn, tt. * from "
					      + "(select * from imageboard order by seq desc) tt)"
					      + "where rn>=? and rn<=?" ;
			
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, last);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				imageboardDTO = new ImageBoardDTO();
				imageboardDTO.setSeq(rs.getInt("seq"));
				imageboardDTO.setImageName(rs.getString("imageName"));
				imageboardDTO.setImagePrice(rs.getInt("imagePrice"));
				imageboardDTO.setImageQty(rs.getInt("imageQty"));
				imageboardDTO.setImageContent(rs.getString("imageContent"));
				imageboardDTO.setImageFile(rs.getString("imageFile"));
				list.add(imageboardDTO);
			
				
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return list;
	}
	
	public int getTotalArticle() {
			
			int total = 0;
			
			try {
				
				 con = ds.getConnection(); // getConnection()은 DB 연결을 위한 메소드로, 구현에 따라 달라질 수 있습니다.
			     String query = "SELECT COUNT(*) FROM imageboard"; // 쿼리는 실제 테이블명으로 수정해야 합니다.
			     pstmt = con.prepareStatement(query);
			     rs = pstmt.executeQuery();
				
			     if (rs.next()) {
			    	 total = rs.getInt(1); // 첫 번째 컬럼의 값을 가져옵니다. 일반적으로 COUNT(*)의 결과가 첫 번째 컬럼에 위치합니다.
			     }   
	
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				streamClose(rs, pstmt, con);
			}
			
			return total;
			
		}// getTotalArticle end
	
	
	 public ImageBoardDTO inagrboardInfo(int seq) {
	        ImageBoardDTO imageboardDTO = null;

	        try {
	        	con = ds.getConnection();
	            String query = "SELECT * FROM imageboard WHERE seq=?";
	            pstmt = con.prepareStatement(query);
	            pstmt.setInt(1, seq);
	            rs = pstmt.executeQuery();

	            if (rs.next()) {
	                imageboardDTO = new ImageBoardDTO();
	                imageboardDTO.setSeq(rs.getInt("seq"));
	                imageboardDTO.setImageId(rs.getString("imageId"));
	                imageboardDTO.setImageFile(rs.getString("imageFile"));
	                imageboardDTO.setImageName(rs.getString("imageName"));
	                imageboardDTO.setImagePrice(rs.getInt("imagePrice"));
	                imageboardDTO.setImageContent(rs.getString("imageContent"));
	                imageboardDTO.setImageQty(rs.getInt("imageQty"));
	                // Add other attributes if needed
	            }
	        } catch (Exception e) {
				e.printStackTrace();     
			} finally {
				streamClose(rs, pstmt, con);
			}
			
	        return imageboardDTO;
	    }

	public int imageboardModify(ImageBoardDTO imageboardDTO) {
	
		int su = 0;
		
		try {
			
			String sql = "update imageboard set imageId=?, imageContent=?, imageFile=?, imageName=?, imagePrice=?, imageQty=? where seq=?";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, imageboardDTO.getImageId());
			pstmt.setString(2, imageboardDTO.getImageContent());
			pstmt.setString(3, imageboardDTO.getImageFile());
			pstmt.setString(4, imageboardDTO.getImageName());
			pstmt.setInt(5, imageboardDTO.getImagePrice());
			pstmt.setInt(6, imageboardDTO.getImageQty());
			pstmt.setInt(7, imageboardDTO.getSeq());
			su = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return su;
	} //boardModify end

	public int imageboardDelete(int seq)  {
		int su = 0;
		
		try {
			
			String sql = "DELETE FROM imageboard WHERE seq = ?";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, seq);
			su = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return su;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}