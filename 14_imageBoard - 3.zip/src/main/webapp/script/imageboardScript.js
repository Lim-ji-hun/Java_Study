
/* imageboardScript.js */

function imageWrite(){
	
	if(document.imageboardWriteForm.imageId.value==""){
		alert("상품 코드를 입력하시오");
		document.imageboardWriteForm.imageId.focus();
	}
	 else if (document.imageboardWriteForm.imageName.value==""){
		alert("상품 이름를 입력하시오");
		document.imageboardWriteForm.imageName.focus();
	}
	 else if (document.imageboardWriteForm.imagePrice.value==""){
		alert("상품 가격를 입력하시오");
		document.imageboardWriteForm.imagePrice.focus();
	} 
	else if (document.imageboardWriteForm.imageQty.value==""){
		alert("상품 수량를 입력하시오");
		document.imageboardWriteForm.imageQty.focus();
	}
	 else if (document.imageboardWriteForm.imageContent.value==""){
		alert("상품 정보를 입력하시오");
		document.imageboardWriteForm.imageContent.focus();
	} else {
		document.imageboardWriteForm.submit();
	}
}

function imageModify(){
	if(document.imageboardModifyForm.imageId.value==""){
		alert("상품 코드를 입력하시오");
		document.imageboardModifyForm.imageId.focus();
	}
	 else if (document.imageboardModifyForm.imageName.value==""){
		alert("상품 이름를 입력하시오");
		document.imageboardModifyForm.imageName.focus();
	}
	 else if (document.imageboardModifyForm.imagePrice.value==""){
		alert("상품 가격를 입력하시오");
		document.imageboardModifyForm.imagePrice.focus();
	} 
	else if (document.imageboardModifyForm.imageQty.value==""){
		alert("상품 수량를 입력하시오");
		document.imageboardModifyForm.imageQty.focus();
	}
	 else if (document.imageboardModifyForm.imageContent.value==""){
		alert("상품 정보를 입력하시오");
		document.imageboardModifyForm.imageContent.focus();
	} else {
		document.imageboardModifyForm.submit();
	}
}








































