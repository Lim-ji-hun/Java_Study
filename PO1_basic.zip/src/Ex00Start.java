// 주석은 어쩌고 저쩌고
/* 주석 시작
 * 범위내 주석ㅇㅇㅇ
 * 사용자 명칭 정의 : class, 변수명 ...
- 이름의 첫글자로 숫자 X
- 띄어쓰기 시 스페 X
- 알파벳 대소문자 구별
- 예약어는 변수명 사용 불가
 
* class명 작성 규칙
* - 첫글자는 대문자
* - 합성어의 두번째 단어의 첫글자는 대문자로 시작
주석 끝*/

public class Ex00Start {

	public static void main(String[] args) {
		
		System.out.println("이게 출력 됨 ㅇㅇ");
		
	}
	
}
