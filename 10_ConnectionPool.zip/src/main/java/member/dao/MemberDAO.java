



package member.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import member.dto.MemberDTO;

public class MemberDAO {

	// 연결정보
	private String driver = "oracle.jdbc.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String id = "dbtest";
	private String pwd = "a1234";
	
	private Connection con = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	public MemberDAO() {
		try {
			Class.forName(driver);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection con = null;
		try {
			// DB 연결 객체 생성
			con = DriverManager.getConnection(url, id, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	} // getConnection() end
	
	
	// 회원 가입
	public int write(MemberDTO dto) {
		
		int su = 0;
		
		try {
			
			String sql = "insert into member values(?, ?, ?, ?, ?, ?, ?, ?, sysdate)";
			con = this.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getName());
			pstmt.setString(2, dto.getId());
			pstmt.setString(3, dto.getPwd());
			pstmt.setString(4, dto.getGender());
			pstmt.setString(5, dto.getEmail());
			pstmt.setString(6, dto.getDomain());
			pstmt.setString(7, dto.getTel());
			pstmt.setString(8, dto.getAddr());
			su = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return su;
		
	} // write() end
	
	
	// ID 중복 확인
	public boolean isExistId(String id) {
		
		boolean exist = false;  // true : 사용중, false : 미사용
		
		try {
			
			String sql = "select * from member where id=?";
			con = this.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				exist = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return exist;
		
	} // isExistId() end
	
	

	// 로그인
	public String login(String id, String pwd) {
		
		String name = null;
		
		try {
			
			String sql = "select * from member where id=? and pwd=?";
			con = this.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				name = rs.getString("name");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return name;
		
	} // login() end
	
	//회원정보 가져오기
	public MemberDTO getMember(String id) {
        MemberDTO memberDTO = null;
        
        try {
            String sql = "SELECT * FROM member WHERE id = ?";
            con = this.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                // 회원 정보를 DTO에 설정
                memberDTO = new MemberDTO();
                memberDTO.setId(rs.getString("id"));
                memberDTO.setName(rs.getString("name"));
                memberDTO.setPwd(rs.getString("pwd"));
                memberDTO.setGender(rs.getString("gender"));
                memberDTO.setEmail(rs.getString("email"));
                memberDTO.setDomain(rs.getString("domain"));
                memberDTO.setTel(rs.getString("tel"));
                memberDTO.setAddr(rs.getString("addr"));
            }
        } catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
        
        return memberDTO;
    }
	
	public int modify(MemberDTO dto) {
        
        int su = 0;

        try {
            // SQL 쿼리 작성
            String sql = "UPDATE member SET name=?, pwd=?, gender=?, email=?, domain=?, tel=?, addr=?  WHERE id=?";
            con = this.getConnection();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, dto.getName());
            pstmt.setString(2, dto.getPwd());
			pstmt.setString(3, dto.getGender());
			pstmt.setString(4, dto.getEmail());
			pstmt.setString(5, dto.getDomain());
			pstmt.setString(6, dto.getTel());
			pstmt.setString(7, dto.getAddr());
			pstmt.setString(8, dto.getId());
			
            // 쿼리 실행 및 결과 처리
            su = pstmt.executeUpdate();
        } catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

        return su;
    }
	
	
}

























