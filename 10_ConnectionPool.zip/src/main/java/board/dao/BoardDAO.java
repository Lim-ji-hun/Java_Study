package board.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import board.dto.BoardDTO;

public class BoardDAO {

	private Connection con = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private DataSource ds;
	
	public BoardDAO() {
		try {
			// InitialContext객체 생성해서 설정된 정보 가져오기 : JNDI
			Context context = new InitialContext();
			// Context 클래스의 lookup()메서드는 'java:comp/env/jdbc/oracle'을 가지고 DataSource을 구함
			// - lookup()메서드를 사용해서 naming서비스에서 자원을 찾음
			// - JNDI 의 이름은 java:comp/env에 등록되어 있음
			ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void streamClose(ResultSet rs, PreparedStatement pstmt, Connection con) {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}//streamClose() end
	
	public int write(BoardDTO dto) {
		
		int su = 0;
		
		try {
			
			String sql = "insert into board values(board_seq.nextval, ?, ?, ?, ?, 0, sysdate)";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getSubject());
			pstmt.setString(4, dto.getContent());
			su = pstmt.executeUpdate();
			
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				streamClose(rs, pstmt, con);
			}
			return su;
		}
	
	public ArrayList<BoardDTO> boardList(int start, int last){
		
		ArrayList<BoardDTO> list = new ArrayList<>();
		BoardDTO boardDTO = null;
		
		try {
			
			String sql =  "select seq, id, name, subject, content, hit, to_char(logtime, 'YYYY.MM.DD') as logtime from "
					      + "(select rownum rn, tt. * from "
					      + "(select * from board order by seq desc) tt)"
					      + "where rn>=? and rn<=?" ;
			
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, last);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				boardDTO = new BoardDTO();
				boardDTO.setSeq(rs.getInt("seq"));
				boardDTO.setId(rs.getString("id"));
				boardDTO.setName(rs.getString("name"));
				boardDTO.setSubject(rs.getString("subject"));
				boardDTO.setContent(rs.getString("content"));
				boardDTO.setHit(rs.getInt("hit"));
				boardDTO.setLogtime(rs.getString("logtime"));
				list.add(boardDTO);
			
				
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return list;
		
	}
	
	public int getTotalArticle() {
		
		int total = 0;
		
		try {
			
			 con = ds.getConnection(); // getConnection()은 DB 연결을 위한 메소드로, 구현에 따라 달라질 수 있습니다.
		     String query = "SELECT COUNT(*) FROM board"; // 쿼리는 실제 테이블명으로 수정해야 합니다.
		     pstmt = con.prepareStatement(query);
		     rs = pstmt.executeQuery();
			
		     if (rs.next()) {
		    	 total = rs.getInt(1); // 첫 번째 컬럼의 값을 가져옵니다. 일반적으로 COUNT(*)의 결과가 첫 번째 컬럼에 위치합니다.
		     }   

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		
		return total;
		
	}// getTotalArticle end
	
	public BoardDTO boardView(int seq) {
	    BoardDTO dto = null;
	    
	    try {
	        con = ds.getConnection(); // 데이터베이스 연결
	        String sql = "SELECT * FROM board WHERE seq = ?"; // 해당 글번호의 글 정보를 가져오는 쿼리
	        pstmt = con.prepareStatement(sql);
	        pstmt.setInt(1, seq);
	        rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // 결과에서 글 정보를 가져와 BoardDTO 객체에 설정
	        	dto = new BoardDTO();
	        	dto.setSeq(rs.getInt("seq"));
	        	dto.setId(rs.getString("id"));
	        	dto.setName(rs.getString("name"));
	        	dto.setSubject(rs.getString("subject"));
	        	dto.setContent(rs.getString("content"));
	        	dto.setHit(rs.getInt("hit"));
	        	dto.setLogtime(rs.getString("logtime"));
	            
	            // 글을 조회할 때 조회수를 증가시킵니다.
	            //increaseHit(seq);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        streamClose(rs, pstmt, con); // 사용한 자원을 닫음
	    }
	    
	    return dto;
	    
	    
	}
//      글을 조회할 때 조회수를 증가시킵니다.
//		private void increaseHit(int seq) {
//		    try {
//		        con = ds.getConnection(); // 데이터베이스 연결
//		        String sql = "UPDATE board SET hit = hit + 1 WHERE seq = ?"; // 해당 글의 조회수를 증가시키는 쿼리
//		        pstmt = con.prepareStatement(sql);
//		        pstmt.setInt(1, seq);
//		        pstmt.executeUpdate();
//		    } catch (Exception e) {
//		        e.printStackTrace();
//		    } finally {
//		        streamClose(null, pstmt, con); // 사용한 자원을 닫음 (ResultSet은 사용하지 않으므로 null을 전달)
//		    }
//	
//		}
	
//  글을 조회할 때 조회수를 증가시킵니다 v-2.	
	public void updateHit(int seq) {
	      try {
	         String sql = "UPDATE board SET hit=hit+1 WHERE seq=?";
	         con = ds.getConnection();
	         pstmt = con.prepareStatement(sql);
	         pstmt.setInt(1, seq);
	         rs = pstmt.executeQuery();
	      } catch (Exception e) {
	         e.printStackTrace();
	      } finally {
	         streamClose(rs, pstmt, con);
	      }
	   }// updateHit
	
	//수정
	public int boardModify(BoardDTO boardDTO) {
			
			int su = 0;
			
			try {
				
				String sql = "update board set subject=?, content=? where seq=?";
				con = ds.getConnection();
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, boardDTO.getSubject());
				pstmt.setString(2, boardDTO.getContent());
				pstmt.setInt(3, boardDTO.getSeq());
				su = pstmt.executeUpdate();
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				streamClose(rs, pstmt, con);
			}
			return su;
	} //boardModify end
	
}//BoardDAO() end
