



package imageboard.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import board.dto.BoardDTO;
import imageboard.dto.ImageBoardDTO;

public class ImageBoardDAO {

	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	private DataSource ds;
	
	public ImageBoardDAO() {
		try {
			Context context = new InitialContext();
			ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void streamClose(ResultSet rs, PreparedStatement pstmt, Connection con) {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	} // streamClose() end
	
	
	// 상품 등록
	public int imageboardWrite(ImageBoardDTO imageboardDTO) {
		
		int su = 0;
		
		try {
			
			String sql = "insert into imageboard values(seq_imageboard.nextval, ?, ?, ?, ?, ?, ?, sysdate)";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, imageboardDTO.getImageId());
			pstmt.setString(2, imageboardDTO.getImageName());
			pstmt.setInt(3, imageboardDTO.getImagePrice());
			pstmt.setInt(4, imageboardDTO.getImageQty());
			pstmt.setString(5, imageboardDTO.getImageContent());
			pstmt.setString(6, imageboardDTO.getImageFile());
			su = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return su;
		
	} // imageboardWrite() end
	
	
	// 상품 목록
	public ArrayList<ImageBoardDTO> imageboardList(int start, int last){
		
		ArrayList<ImageBoardDTO> list = new ArrayList<>();
		ImageBoardDTO imageboardDTO = null;
		
		try {
			
			String sql = "select * from "
					     + "(select rownum rn, tt. * from "
					     + "(select * from imageboard order by seq desc) tt)"
					     + "where rn>=? and rn<=?";
			
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, last);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				imageboardDTO = new ImageBoardDTO();
				imageboardDTO.setSeq(rs.getInt("seq"));;
				imageboardDTO.setImageName(rs.getString("imageName"));
				imageboardDTO.setImagePrice(rs.getInt("imagePrice"));
				imageboardDTO.setImageQty(rs.getInt("imageQty"));
				imageboardDTO.setImageContent(rs.getString("imageContent"));
				imageboardDTO.setImageFile(rs.getString("imageFile"));
				list.add(imageboardDTO);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return list;
		
	} // imageboardList() end
	
	
	// 상품 목록수
	public int getTotalArticle() {
		
		int total = 0;
		
		try {
			
			String sql = "select count(*) from imageboard";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				total = rs.getInt(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		
		return total;
		
	} // getTotalArticle() end
	
	
	// 상품 정보
	public ImageBoardDTO imageboardInfo(int seq) {
		
		ImageBoardDTO imageBoardDTO = null;
		
		try {
			
			String sql = "select * from imageboard where seq=?";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, seq);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				imageBoardDTO = new ImageBoardDTO();
				imageBoardDTO.setSeq(rs.getInt("seq"));
				imageBoardDTO.setImageId(rs.getString("imageId"));
				imageBoardDTO.setImageName(rs.getString("imageName"));
				imageBoardDTO.setImagePrice(rs.getInt("imagePrice"));
				imageBoardDTO.setImageQty(rs.getInt("imageQty"));
				imageBoardDTO.setImageContent(rs.getString("imageContent"));
				imageBoardDTO.setImageFile(rs.getString("imageFile"));
				imageBoardDTO.setLogtime(rs.getString("logtime"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return imageBoardDTO;
		
	} // imageboardInfo() end
	
}
























