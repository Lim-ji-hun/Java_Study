



package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import board.dto.BoardDTO;

public class BoardDAO {

	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	private DataSource ds;
	
	public BoardDAO() {
		try {
			// InitialContext 객체 생성해서 설정된 정보 가져오기 : JNDI
			Context context = new InitialContext();
			
			// Context 클래스의 lookup() 메서드는 'java:comp/env/jdbc/oracle' 을 가지고 DataSource 객체를 구합니다
			// - lookup() 메서드를 사용해서 naming 서비스에서 자원을 찾습니다
			// - JNDI 의 이름은 'java:comp/env' 에 등록되어 있습니다
			ds = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void streamClose(ResultSet rs, PreparedStatement pstmt, Connection con) {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	} // streamClose() end
	
	
	// 글쓰기
	public int write(BoardDTO dto) {
		
		int su = 0;
		
		try {
			
			String sql = "insert into board values(board_seq.nextval, ?, ?, ?, ?, 0, sysdate)";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getSubject());
			pstmt.setString(4, dto.getContent());
			su = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return su;
		
	} // write() end
	
	
	// 글목록
	public ArrayList<BoardDTO> boardList(int start, int last){
		
		ArrayList<BoardDTO> list = new ArrayList<>();
		BoardDTO boardDTO = null;
		
		try {
			
			String sql = "select seq, id, name, subject, content, hit, to_char(logtime, 'YYYY.MM.DD') as logtime from "
					     + "(select rownum rn, tt. * from "
					     + "(select * from board order by seq desc) tt)"
					     + "where rn>=? and rn<=?";
			
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, last);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				boardDTO = new BoardDTO();
				boardDTO.setSeq(rs.getInt("seq"));;
				boardDTO.setId(rs.getString("id"));
				boardDTO.setName(rs.getString("name"));
				boardDTO.setSubject(rs.getString("subject"));
				boardDTO.setContent(rs.getString("content"));
				boardDTO.setHit(rs.getInt("hit"));
				boardDTO.setLogtime(rs.getString("logtime"));
				list.add(boardDTO);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return list;
		
	} // boardList() end
	
	
	// 전체 글수
	public int getTotalArticle() {
		
		int total = 0;
		
		try {
			
			String sql = "select count(*) from board";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				total = rs.getInt(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		
		return total;
		
	} // getTotalArticle() end
	
	
	// 조회수 증가
	public void updateHit(int seq) {
		
		try {
			
			String sql = "update board set hit=hit+1 where seq=?";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, seq);
			pstmt.executeUpdate();
	
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		
	} // updateHit() end
	
	
	// 글보기
	public BoardDTO boardView(int seq) {
		
		BoardDTO boardDTO = null;
		
		try {
			
			String sql = "select * from board where seq=?";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, seq);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				boardDTO = new BoardDTO();
				boardDTO.setSeq(rs.getInt("seq"));
				boardDTO.setId(rs.getString("id"));
				boardDTO.setName(rs.getString("name"));
				boardDTO.setSubject(rs.getString("subject"));
				boardDTO.setContent(rs.getString("content"));
				boardDTO.setHit(rs.getInt("hit"));
				boardDTO.setLogtime(rs.getString("logtime"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return boardDTO;
		
	} // boardView() end
	
	
	// 글수정
	public int boardModify(BoardDTO boardDTO) {
		
		int su = 0;
		
		try {
			
			String sql = "update board set subject=?, content=? where seq=?";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, boardDTO.getSubject());
			pstmt.setString(2, boardDTO.getContent());
			pstmt.setInt(3, boardDTO.getSeq());
			su = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return su;
		
	} //boardModify() end
	
	
	// 글삭제
	public int boardDelete(int seq) {
		
		int su = 0;
		
		try {
			
			String sql = "delete from board where seq=?";
			con = ds.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, seq);
			su = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			streamClose(rs, pstmt, con);
		}
		return su;
		
	}
	
	
}

























