/*
 * 정적 중첩 클래스
 * 
 */
class OuterS{
	public static int a;
	private int b;
	
	static { a=1;}
	
	public OuterS() { b=2;}
	
	public void outerSinfo() {
		System.out.println("-outerSinfo-");
		System.out.println("a : "+ a);
		System.out.println("b : "+ b);

	}
	
	static class InnerS {
		
		public static int c;
		private int d;
		
		static { c = 3;}
		
		public InnerS() { d = 4;}
		
		public void innerSinfo() {
			System.out.println("innerSinfo()");
			System.out.println("a : "+ a);
			//System.out.println("b : "+ b); error 외부클래스의 일반 멤버는 사용 불가
			System.out.println("c : "+ c);
			System.out.println("d : "+ d);
		}
	}
}

class MySystem{
	static final class Inner{
		void println(String message) {
			System.out.println(message);
		}
	}
	static final Inner out = new Inner();
	
}

public class EX02Static {
	
	public static void main(String[] args) {
		
		OuterS.InnerS oi = new OuterS.InnerS();
		oi.innerSinfo();
		
		System.out.println();
		
		MySystem.out.println("dygn");
	
	}

}