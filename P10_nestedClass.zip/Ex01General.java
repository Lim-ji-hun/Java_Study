
/*
 * 일반 중첩 클래스
 * 
 * 
 * 
 */
class OuterG{
	public static int a;
	private int b;
	
	static { a=1;}
	
	public OuterG() { b=2;}
	
	public void outerGinfo() {
		System.out.println("-outerGinfo-");
		System.out.println("a : "+ a);
		System.out.println("b : "+ b);

	}
	
	class InnerG{
		
		// public static int c; error -> InnerG는 혼자서 생성 불가하기에 OuterG가 필요함 그렇기에 Static과 상반되어 사용 불가
		private int d;
		
		public InnerG() { d = 4; }
		
		public void innerGinfo() {
			System.out.println("- innerGinfo() -");
			System.out.println("a : "+ a);
			System.out.println("b : "+ b);
			System.out.println("d : "+ d);
			
			
		}
		
	}
	
}

public class Ex01General {
	
	public static void main(String[] args) {
		
		OuterG outer = new OuterG();
		outer.outerGinfo();
		
		System.out.println();
		
		//InnerG inner = new InnerG(); // errer
		OuterG.InnerG oi = outer.new InnerG();
		oi.innerGinfo();
		
		
		
	}

}
