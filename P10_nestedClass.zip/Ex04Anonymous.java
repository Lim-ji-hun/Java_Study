/*
 * 익명 중첩 클래스
 * 
 */
class Anony {
	
	public void info() {
		System.out.println("-Anony info()-");
		
	}
}

public class Ex04Anonymous {
	public static void main(String[] args) {
		
		Anony anony = new Anony() {
			public void info() {
				System.out.println("즐거운 하루!");
			}
		};
		
		anony.info();
		
	}

}
