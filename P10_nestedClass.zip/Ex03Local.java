/*
 * 지역 중첩 클래스
 * 
 * 
 */

class OuterL {
	private int a;
	
	public OuterL() { a=1; }
	
	public void info() {
		
		class Local {
			
			private int b;
			
			public Local() {b = 2;}	
			
			public void localInfo() {
				System.out.println("a : "+ a);
				System.out.println("b : "+ b);
				
				
			}

		}
		Local li = new Local();
		li.localInfo();
	}
	
}

public class Ex03Local {
	
	public static void main(String[] args) {
		
		OuterL ol = new OuterL();
		ol.info();
		
		
		
	}

}
