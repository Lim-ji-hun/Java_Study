package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.SchoolDTO;

public class SchoolDAO {

	// 연결정보
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String id = "dbtest";
	private String pwd = "a1234";
	
	public SchoolDAO() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection con = null;
		try {
			// DB 연결 객체 생성
			con = DriverManager.getConnection(url, id, pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	} // getConnection() end
	
	
	// 추가
	public boolean insert(SchoolDTO dto) {
		
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean check = false;  // 성공 : true, 실패 : false
		
		try {
			
			String sql = "insert into school values(?, ?, ?)";
			con = this.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getName());
			pstmt.setString(2, dto.getValue());
			pstmt.setInt(3, dto.getCode());
			int su = pstmt.executeUpdate();
			if(su > 0) {
				check = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return check;
		
	} // insert() end
	
	
	// 검색
	public void search(SchoolDTO dto) {
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			String sql = null;
			if(dto == null) {
				sql = "select * from school";
			} else if(dto.getName() != null) {
				sql = "select * from school where name like ?";
			} else {
				sql = "select * from school where code=?";
			}
			
			con = this.getConnection();
			pstmt = con.prepareStatement(sql);
			if(dto != null) {
				if(dto.getName() != null) {
					pstmt.setString(1, "%"+dto.getName()+"%");
				} else {
					pstmt.setInt(1, dto.getCode());
				}
			}
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String name = rs.getString("name");
				String value = rs.getString("value");
				int code = rs.getInt("code");
				System.out.print(name + "\t");
				if(code == 1) {
					System.out.println("학번 : " + value);
				} else if(code == 2) {
					System.out.println("과목 : " + value);
				} else {
					System.out.println("부서 : " + value);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	} // search() end
	
	
	// 목록
	public ArrayList<SchoolDTO> getList(){
		
		ArrayList<SchoolDTO> list = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			
			String sql = "select * from school";
			con = this.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String name = rs.getString("name");
				String value = rs.getString("value");
				int code = rs.getInt("code");
				
				list.add(new SchoolDTO(name, value, code));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
		
	} // getList() end
	
}
