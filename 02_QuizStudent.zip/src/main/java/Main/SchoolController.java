package Main;
import java.util.List;
import java.util.Scanner;

import dao.SchoolDAO;
import dto.SchoolDTO;

public class SchoolController {

	private Scanner scanner = new Scanner(System.in);
	private SchoolDAO dao = null;
	
	public SchoolController() {
		dao = new SchoolDAO();
		menu();
	}
	
	
	public void menu() {
		 
		while(true) {
			System.out.println("-----  menu  -----");
			System.out.print("1.등록  2.검색  3.삭제  4.목록  5.종료\n선택 >> ");
			int num = scanner.nextInt();
			System.out.println();
			
			switch(num) {
			case 1: // 등록
				insert();
				break;
			case 2: // 검색
				search();
				break;
			case 3: // 삭제
				break;
			case 4: // 목록
				list();
				break;
			case 5: // 종료
				exit();
			default: 
				System.out.println("선택 오류~");
			}
			System.out.println();
		}
		
	} // menu() end
	
	
	// 코드 설정
	public int codeInput() {
		System.out.println("--- 코드 선택 ---");
		System.out.println("1. 학생");
		System.out.println("2. 교수");
		System.out.println("3. 관리자");
		System.out.println("4. 이전");
		System.out.print("선택 > ");
		int code = scanner.nextInt();
		return code;
	} // codeInput()	
	
	
	// 값 설정
	public String valueInput(int code) {
		if(code == 1) {
			System.out.print("학번 입력 >> ");		
		} else if(code == 2) {
			System.out.print("과목 입력 >> ");
		} else {
			System.out.print("부서 입력 >> ");
		}
		String value = scanner.next();
		return value;
	} // valueInput() end
	
	
	// 등록
	public void insert() {
		System.out.println("-----  등   록  -----");
		int code = codeInput();
		if(code < 1 || code > 3) {
			System.out.println("이전 메뉴로 이동합니다~");
			return;
		}
		System.out.print("이름 입력 >> ");
		String name = scanner.next();
		String value = valueInput(code);
		
		SchoolDTO dto = new SchoolDTO(name, value, code);
		boolean check = dao.insert(dto);
		if(check) {
			System.out.println(name + "님이 등록 되었습니다..");
		} else {
			System.out.println("등록 실패~");
		}
	} // insert()
	
	
	// 검색
	public void search() {
		
		System.out.println("-----  검   색  -----");
		System.out.println("1.이름  2.코드  3.전체  4.이전");
		System.out.print("선택 >> ");
		int num = scanner.nextInt();
		if(num < 1 || num > 3) {
			System.out.println("이전 메뉴로 이동합니다~");
		}
		
		SchoolDTO dto = null;
		if(num == 1) {
			dto = new SchoolDTO();
			System.out.print("검색 이름 입력 >> ");
			dto.setName(scanner.next());
		} else if(num == 2) {
			int code = codeInput();
			if(code < 1 || code > 3) {
				System.out.println("없는 코드 입니다~");
				return;
			}
			dto = new SchoolDTO();
			dto.setCode(code);
		}
		dao.search(dto);
		
	} // search() end
	
	
	// 목록
	public void list() {
		List<SchoolDTO> list = dao.getList();
		System.out.println("-----  목   록  -----");
		for(SchoolDTO man : list) {
			System.out.print(man.getName() + "\t");
			if(man.getCode() == 1) {
				System.out.println("학번 : " + man.getValue());
			} else if (man.getCode() == 2) {
				System.out.println("과목 : " + man.getValue());
			} else {
				System.out.println("부서 : " + man.getValue());
			}
		}
	} // list() end
	
	
	// 종료
	public void exit() {
		System.out.println("- Program end -");
		System.exit(0);
	}
	
}