package Main;

import dao.SchoolDAO;
import dto.SchoolDTO;

public class SchoolMain {
	public static void main(String[] args) {
		SchoolDAO dao = new SchoolDAO();
		dao.getConnection();
		
		SchoolController controller = new SchoolController();
		
	}
}

